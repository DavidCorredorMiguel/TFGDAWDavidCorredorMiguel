<?php
if ($paginacion) {
    echo "</td></tr><tr><td colspan='4'><div class='paginacion'><br>";
    if ($pagina != 1) { // Muestro la paginacion de los productos
        echo " <a href='Index.php?pagina=1' id='botonesazules'>Primera</a> 
                <a href='Index.php?pagina=" . ($pagina - 1) . "' id='botonesazules'>Anterior</a> ";
    }
    for ($i = $pagina - 1; $i < $pagina + 2; $i++) {
        if ($i >= 1 && $i <= $numpag) {
            echo " <a href='Index.php?pagina=" . $i . "' id='botonesazules'>$i</a> ";
        }
    }
    if ($pagina != $numpag) {
        echo " <a href='Index.php?pagina=" . ($pagina + 1) . "' id='botonesazules'>Siguiente</a> 
                <a href='Index.php?pagina=$numpag' id='botonesazules'>Ultima</a> ";
    }
    echo "<br><br></div></td></tr></table>";
}
if ($acceso2coment) { // Comentarios del producto
    echo "<table style='background-color: white' id='tablaprod'><tr><td colspan='5' style='padding: 0px'>
    <div style='background-color: yellow; padding: 10px'>
            <strong>Mostrando Comentarios Del Producto: " . $_GET["nombre"] ."</strong></div></td></tr><tr>";
    foreach ($vectorcomentp as $reg2cp) {
        echo "<td><td><img src='imagenesusuarios/" . $reg2cp["imagenusuario"] . "' id='imgusu'><br><span>"
            . $reg2cp['nombreusuario'] . "</span></td><td><span>Valoración:</span> " . $reg2cp['valoracion'] .
            "</td><td><span>Comentario:</span><br><textarea cols='30' rows='1' disabled>" . $reg2cp['comentario'] .
            "</textarea></td><td><span>Fecha:</span> " . $reg2cp['fecha'] . "</div><br></td></tr>";
    }
    echo "</td></tr>";
}
if ($acceso3coment) { // Comentarios de la tienda
    echo "<table style='background-color: white' id='tablaprod'><tr><td colspan='5' style='padding: 0px'>
    <div style='background-color: yellow; padding: 10px'>
            <strong>Mostrando Comentarios De La Tienda: $totalComentarios En Total</strong></div></td></tr><tr>";
    foreach ($vectorcomentt as $reg2c) {
        echo "<td><td><img src='imagenesusuarios/" . $reg2c["imagenusuario"] . "' id='imgusu'><br><span>"
            . $reg2c['nombreusuario'] . "</span></td><td><span>Valoración:</span> " . $reg2c['valoracion'] .
            "</td><td><span>Comentario:</span><br><textarea cols='30' rows='1' disabled>" . $reg2c['comentario'] .
            "</textarea></td><td><span>Fecha:</span> " . $reg2c['fecha'] . "</div><br></td></tr>";
    }
    echo "</td></tr>";
}
if ($footer0coment) { // Footer comentarios e información Sin Conexion
    echo "<footer><br><table><tr><td><h4>Comentarios De La Tienda</h4>
            <div style='margin: 10px; padding: 10px'>";
    foreach ($vectorcomt as $reg2) {
        echo "<img src='imagenesusuarios/" . $reg2["imagenusuario"] . "' id='imgusu'> <span>"
            . $reg2['nombreusuario'] . "</span><br><span>Fecha:</span> " . $reg2['fecha'] .
            "<br><span>Valoración:</span> " . $reg2['valoracion'] .
            "<br><span>Comentario:</span><br>
             <textarea cols='30' rows='1' disabled>" . $reg2['comentario'] . "</textarea><br>";
    }
    echo "<form action='Index.php' method='post'>
            <input type='submit' value='Ver Mas Comentarios De Tienda' name='comentariost0'><br><br></form>
            </div></td><td><h4>Añadir Un Comentario y Valoración Sobre La Tienda:</h4>
          <form action='Index.php' method='post'><span>Valoración (1-10):</span> 
          <input type='number' min='1' max='10' name='valoraciontienda' disabled><br><br>
          <textarea name='comentariotienda' cols='100' rows='5' disabled></textarea><br>
          <input type='submit' name='iniciasesion' value='Enviar Comentario Tienda'></form>
          </td></tr></table><table><tr>";
    foreach ($vectori as $regi) {
        echo "<td><span>Direccion:</span> " . $regi['direccion'] .
            "<br><span>Email:</span> " . $regi['email'] .
            "<br><span>Teléfono De Contacto:</span> " . $regi['telefonocontacto'] . "<br><br></td>";
    }
    echo "<td><h4>Creada Por David Corredor Miguel</h4></td></tr></table></footer>";
}
if ($footer1coment) { // Footer comentarios e información Con Conexion
    echo "<footer><br><table><tr><td><h4>Comentarios De La Tienda</h4>
            <div style='margin: 10px; padding: 10px'>";
    foreach ($vectorcomt as $reg2) {
        echo "<img src='imagenesusuarios/" . $reg2["imagenusuario"] . "' id='imgusu'> <span>"
            . $reg2['nombreusuario'] . "</span><br><span>Fecha:</span> " . $reg2['fecha'] .
            "<br><span>Valoración:</span> " . $reg2['valoracion'] . "<br><span>Comentario:</span><br>
             <textarea cols='30' rows='1' disabled>" . $reg2['comentario'] . "</textarea><br>";
    }
    foreach ($imagenusuarios as $imagenusuario) {
        echo "<form action='Index.php' method='post'>
            <input type='submit' value='Ver Mas Comentarios De Tienda' name='comentariost'><br><br></form>
            </div></td><td><h4>Añade Un Comentario y Valoración Sobre La Tienda:</h4>
          <form action='Index.php' method='post'><span>Valoración (1-10):</span> 
          <input type='hidden' name='usuariocomentariotienda' value='" . $_SESSION["user"] . "'>
          <input type='hidden' name='imagenusuariocomentario' value='" . $imagenusuario["imagenusuario"] . "'>
          <input type='number' min='1' max='10' name='valoraciontienda'><br><br>
          <textarea name='comentariotienda' cols='100' rows='5'></textarea><br>
          <input type='submit' name='enviacomentariotienda' value='Enviar Comentario Tienda'></form><br>
          </td></tr></table><table><tr>";
    }
    foreach ($vectori as $regi) {
        echo "<td><span>Direccion:</span> " . $regi['direccion'] . "<br><span>Email:</span> " . $regi['email'] .
            "<br><span>Teléfono De Contacto:</span> " . $regi['telefonocontacto'] . "<br><br></td>";
    }
    echo "<td><h4>Creada Por David Corredor Miguel</h4></td></tr></table></footer>";
}
?>