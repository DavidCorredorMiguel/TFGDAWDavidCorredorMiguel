<?php
if ($accesosesion) { // Formulario para iniciar sesion
?>
    <table align="center">
        <tr>
            <td colspan="3">
                <h1>ACCESO TIENDA</h1><form action="<?php $_SERVER["PHP_SELF"] ?>" method="post">
            </td>
        </tr>
        <tr>
            <td colspan="3"><span>Usuario:</span></td>
        </tr>
        <tr>
            <td colspan="3"><input type="text" name="user"></td>
        </tr>
        <tr>
            <td colspan="3"><span>Contraseña:</span></td>
        </tr>
        <tr>
            <td colspan="3"><input type="password" name="pass"></td>
        </tr>
        <tr>
            <td colspan="3"><span>Recordar:</span> <input type="checkbox" name="recuerda"></td>
        </tr>
        <tr>
            <td><a href="Index.php?option=registrar" id="inisesion">Crear Usuario</a></td>
            <td><input type="submit" value="Iniciar Sesion" name="iniciar"></form>
            </td>
            <td>
                <form action='Index.php' method='post'><input type='submit' value='Volver A Inicio'></form>
            </td>
        </tr>
    </table>
<?php
}
?>