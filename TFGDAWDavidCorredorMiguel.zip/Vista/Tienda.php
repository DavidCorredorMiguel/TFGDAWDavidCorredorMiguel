<?php
if ($acceso1) { // Página de Inicio Con Sesión
    if ($tipousuario == "usuario") { // Muestro los productos para el usuario
        echo "<table><tr><td><div class='col-md-2' style='border-right: 1px solid black'>
          <h3 style='text-decoration: underline'>Subcategorias De Productos</h3>";
        foreach ($subtipos as $subtipop) {
            echo "<form action='Index.php?subtipo=$subtipop' method='post'><br>
              <input type='submit' value='$subtipop' id='subtipo' name='buscarsubtipo'></form>";
        }
        echo "</div>";
        foreach ($vectorp as $reg2) {
            echo "<div class='col-md-3'><br><br><section class='section'><img src='imagenes/" . $reg2['imagen'] .
                "' width='200px' name='imagencesta'><form action='Index.php?nombre=" . $reg2['nombre'] .
                "' method='post'><br><input type='submit' value='" . $reg2['nombre'] .
                "' class='nombre' name='detalles'><br></form><h3>" . $reg2['precio'] . " €</h3><br></section></div>";
        }
    } else { // Muestro en la tabla el formulario del admin
        if (isset($buscaActualizar)) { // Muestro el formulario del admin para actualizar producto
            echo "<br><div id='contenedor' style='width: 1000px' align='center'><table><tr><td colspan='2'>
		        <h1 style='color: white'>Actualizar Producto</h1></td></tr><tr><td>
                <form action='Index.php?idproducto=" . $_GET["idproducto"] . 
                "' method='post' enctype='multipart/form-data'><label>Tipo: </label><br>
                <textarea name='tipo' cols='70' rows='1'>" . $buscaActualizar['tipo'] .
                "</textarea><br><br><label>Subtipo: </label><br><textarea name='subtipo' cols='70' rows='1'>" .
                $buscaActualizar['subtipo'] . "</textarea><br><br><label>Nombre: </label><br>
                <textarea name='nombre' cols='70' rows='1'>" . $buscaActualizar['nombre'] . "</textarea><br><br>
                <label>Descripcion: </label><br><textarea name='descripcion' cols='70' rows='5'>" .
                $buscaActualizar['descripcion'] . "</textarea></td><td><label>Cantidad: </label><br>
                <input type='number' value='" . $buscaActualizar['cantidad'] . "' name='cantidad'><br><br><label>Precio:
                </label><br><input type='number' value='" . $buscaActualizar['precio'] . 
                "' min='0.01' step='0.01' name='precio'><br><br><label>Imagen: </label><br><input type='file' value='"
                 . $buscaActualizar['imagen'] . "' name='imagen'></td></tr><tr><td colspan='2'>
                 <input type='submit' value='Actualizar' name='actualizar2'></form></td></tr></table></div><br>";
        }
        if ($borrarSeguro) { // Muestro el formulario del admin para confirmar borrado
            if (isset($_GET["idproducto"])) {
                echo "<br><div id='contenedor' align='center'><h1 style='color: white'>Borrar</h1>
            <form action='Index.php?idproducto=" . $_GET["idproducto"] . "' method='post'>
            <h4 style='color: white'>¿Borrar el producto?</h4>
            <input style='padding:10px' type='submit' value='Borrar' name='borrar2'>
            <input style='padding:10px' type='submit' value='Cancelar' name='cancelar'></form><br></div><br>";
            }
        }
        echo "<table cellspacing='0'><tr><th style='text-align: center; padding: 10px; border: 1px solid black'>
        Detalles Del Producto</th><th style='text-align: center; padding: 10px; border: 1px solid black'>Imagen</th>
        <th style='text-align: center; padding: 10px; border: 1px solid black'>Opciones</th></tr>";
        foreach ($vectorp as $reg2) {
            echo "<form action='Index.php?idproducto=" . $reg2['idproducto'] . "' method='post'>
                <tr style='border-bottom: 1px solid black'><td style='padding: 10px'><span>Tipo:</span> " . 
                $reg2['tipo'] . " | <span>Subtipo:</span> " . $reg2['subtipo'] . " | <span>Nombre:</span> " . 
                $reg2['nombre'] . " | <span>Cantidad:</span> " . $reg2['cantidad'] . " | <span>Precio:</span> " . 
                $reg2['precio'] . "<br><br><span>Descripcion:</span> " . $reg2['descripcion'] . 
                "</td><td align='center' style='padding: 10px'><img src='imagenes/" . $reg2['imagen'] .
                "' width='150px'></td><td style='padding: 10px'>
                <input id='botonesazules' type='submit' value='Borrar' name='borrar'><br><br>
                </form><form action='Index.php?idproducto=" . $reg2['idproducto'] . "' method='post'>
                <input id='botonesazules' type='submit' value='Acutalizar' name='actualizar'></form></td>";
        }
        echo "<tr><th style='text-align: center; padding: 10px; border: 1px solid black' colspan='3'>Insertar Producto
        </th></tr><tr><td style='padding: 10px' align='center'>
        <form action='Index.php' method='post' enctype='multipart/form-data'>
        <label>Tipo:</label><br><textarea name='tipo' cols='70' rows='1'></textarea><br>
        <label>Subtipo:</label><br><textarea name='subtipo' cols='70' rows='1'></textarea><br>
        <label>Nombre:</label><br><textarea name='nombre' cols='70' rows='1'></textarea><br>
        <label>Descripcion:</label><br><textarea name='descripcion' cols='70' rows='5'></textarea><br>
        </td><td style='padding: 10px' align='center'><label>Cantidad:</label><br><input type='number' name='cantidad'>
        <br><br><label>Precio:</label><br><input type='number' min='0.01' step='0.01' name='precio'><br>
        <label>Imagen:</label><br><input type='file' name='imagen'></td>
        <td style='padding: 20px' align='center' colspan='2'>
        <input id='botonesazules' type='submit' name='insertar' value='Insertar'></form>";
    }
}
if ($accesoimagen) { // Muestro el formulario para cambiar imagen
    echo "<div><table><tr><td align='center'><br><br><h4>Selecciona imagen para actualizar</h4><br>
    <br><form action='Index.php' method='post' enctype='multipart/form-data'>
    <input type='file' name='imagenusuariocambia'><br><br></td></tr><tr><td>
    <input type='submit' value='Cambiar Imagen Nueva' name='cambiarimagen'></form></td></tr></table><br></div>";
}
if ($acceso2b) { // Muestro detalles del producto seleccionado
    echo "<table>";
    if (isset($detallesproducto)) {
        echo "<tr><td><img src='imagenes/" . $detallesproducto['imagen'] . "' name='imagencesta'></td>
        <td colspan='2' style='padding: 20px'><h1 id='nombreprod'>"
            . $detallesproducto['subtipo'] . " " . $detallesproducto['nombre'] . "</h1><br>
        <form action='Index.php?nombre=" . $detallesproducto['nombre'] . "'method='post'>
        <span>Selecciona Cantidad Antes De Añadir a La Cesta</span>
        </div><br><br><span>Disponible:</span> " . $detallesproducto['cantidad'] . " unidades 
        <br><span>Cantidad A Elegir:</span> <input type='number' min='1' max='"
            . $detallesproducto['cantidad'] . "'name='cantidadcesta' id='prod'>
        <br><span>Precio:</span> " . $detallesproducto['precio'] . " €<br>
        <input hidden='hidden' name='idproductocesta' value='" . $detallesproducto['idproducto'] . "'>
        <input hidden='hidden' name='subtipocesta' value='" . $detallesproducto['subtipo'] . "'>
        <input hidden='hidden' name='nombrecesta' value='" . $detallesproducto['nombre'] . "'>
        <input hidden='hidden' name='preciocesta' value='" . $detallesproducto['precio'] . "'>
        <input hidden='hidden' name='imagencesta' value='" . $detallesproducto['imagen'] . "'>
        <input type='hidden' name='nombreusuario' value='" . $_SESSION["user"] . "'>
        <br><form action='Index.php' method='post'>
        <input type='submit' name='anadecesta' value='Añadir A La Cesta'></form>
        </form><br><span>Detalles Técnicos<br></span>" . $detallesproducto['descripcion'] . "<br><br></td></tr>
        <br><table><tr><td><h4>Comentarios Del Producto</h4><div style='margin: 10px; padding: 10px'>";
        foreach ($vectorcomtp as $reg2) {
            echo "<img src='imagenesusuarios/" . $reg2["imagenusuario"] . "'
             style='width: 40px; border-radius: 30px'> <span>" . $reg2['nombreusuario'] .
                "</span><br><span>Fecha:</span> " . $reg2['fecha'] .
                "<br><span>Valoración:</span> " . $reg2['valoracion'] .
                "<br><span>Comentario:</span><br>
             <textarea cols='30' rows='1' disabled>" . $reg2['comentario'] . "</textarea><br>";
        }
        echo "<form action='Index.php?nombre=" . $detallesproducto['nombre'] . "' method='post'>
            <input type='submit' value='Ver Mas Comentarios' name='comentariosp'><br><br></form>";
        foreach ($imagenusuarios as $imagenusuario) {
            echo "<form action='Index.php?nombre=" . $detallesproducto['nombre'] . "' method='post'></div>
            </td><td><h4>Añade Un Comentario y Valoración Del Producto:</h4>
          <form action='Index.php' method='post'><span>Valoración (1-10):</span> 
          <input type='hidden' name='usuariocomentarioprod' value='" . $_SESSION["user"] . "'>
          <input type='hidden' name='imagenusuariocomentario' value='" . $imagenusuario["imagenusuario"] . "'>
          <input type='hidden' name='nombreproducto' value='" . $detallesproducto['nombre'] . "'>
          <input type='number' min='1' max='10' name='valoracionprod'><br><br>
          <textarea name='comentarioprod' cols='100' rows='5'></textarea><br>
          <input type='submit' name='enviacomentarioprod' value='Enviar Comentario Producto'></form>
          </td></tr></table>";
        }
    }
}
if ($acceso3b) { // Muestro los productos buscados por tipo o subtipo
    if ($paginaactual == 0) {
        $paginaactual = 1;
    }
    echo "<table><tr><td><div class='col-md-2' style='padding: 20px; border-right: 1px solid black'>
    <h3 style='text-decoration: underline'>Subcategorias De Productos</h3>";
    foreach ($subtipos as $subtipop) {
        echo "<form action='Index.php?subtipo=$subtipop' method='post'><br>
              <input type='submit' value='$subtipop' id='subtipo' name='buscarsubtipo'></form>";
    }
    echo "</div>";
    foreach ($vector as $reg2) {
        echo "<div class='col-md-3'><br><br><section class='section'>
              <img src='imagenes/" . $reg2['imagen'] . "' width='200px' name='imagencesta'>
              <form action='Index.php?nombre=" . $reg2['nombre'] . "' method='post'><br>
              <input type='submit' value='" . $reg2['nombre'] . "' class='nombre' name='detalles'>
              <br></form><h3>" . $reg2['precio'] . " €</h3><br></section></div>";
    }
    echo "</td></tr>";
}
if ($acceso4) { // Muestro los productos de la cesta del usuario
    echo "<table style='border: 1px solid black; font-weight: bold'>
    <tr style='border: 1px solid black; text-decoration: underline'><td style='padding: 10px'>Nombre</td>
    <td>Imagen</td><td>Cantidad</td><td>Precio</td><td>Total Producto</td><td>Opciones</td><tr>";
    foreach ($vectorc as $reg2) {
        echo "<tr style='border: 1px solid black'><td><form action='Index.php?nombre="
            . $reg2['nombreproducto'] . "' method='post'><span id='nombreprod'>" . $reg2['subtipoproducto'] .
            ":</span> <input type='submit' value='" . $reg2['nombreproducto'] . "' class='nombre' name='detalles'>
            <br></form></td><td style='padding: 10px'><img src='imagenes/" . $reg2['imagenproducto'] .
            "' width='150px'></td><td>" . $reg2['cantidadproducto'] . "</td><td>" . $reg2['precioproducto'] .
            " €</td><td>" . $reg2['totalproducto'] . " €</td></form><td>
            <form action='Index.php' method='post'><input type='number' hidden='hidden' name='idproductocesta'
             value='" . $reg2['idproducto'] . "'><input type='submit' value='Borrar' name='borrap'></form></td>";
    }
    foreach ($totalprecio as $totalpreciop) {
        echo "<tr><td style='text-align: right; padding: 10px'colspan='4'><span>Total Gasto De Los Productos -></span>
        </td><td align='center' style='font-weight: bold; background-color: white' colspan='2'>"
            . $totalpreciop . " €</td></tr>";
    }
    echo "</td></tr></table><table><tr>
          <td style='padding: 10px' colspan='3'><form action='Index.php' method='post'>
          <input hidden='hidden' name='nombreusuario' value='" . $_SESSION["user"] . "'>
          <input type='submit' value='Vaciar Carrito' name='vaciacesta'></form></td>
          <td style='padding: 10px' colspan='3'><form action='Index.php' method='post'>
          <input type='submit' value='Comprar' name='comprar'></form></td></tr></table>";
}
?>