<?php
if ($acceso5a) { // Si pulso en Comprar muestra el formulario para ver el número de tarjeta
    echo "<table><tr><td colspan='2'><img src='Imagenes/Tarjeta-American-Express.jpg' id='logo2'>
    <img src='Imagenes/Tarjeta-MasterCard.png' id='logo2'><img src='Imagenes/Tarjeta-Vista.png' id='logo2'>
    <form action='Index.php' method='post'><input type='hidden' name='usuariotarjeta' value='" .
    $_SESSION["user"] . "'><br><select name='numtarjeta'><option>Numero De La Tajeta: </option>";
    foreach ($numerotajeta as $numerotajetas) {
        echo "<option value='$numerotajetas'>$numerotajetas</option>";
    }
    echo "</select><br><br><span>Esta operación no sera anotada en la tarjeta hasta la confirmacion de la compra de 
    los productos</span></td></tr><tr><td><input type='submit' value='Continuar' name='continuarpago' id='continuar'>
    </form><td><form action='Index.php' method='post'><br>
    <input type='submit' value='Insertar Tarjeta' name='insertanuevatarjeta'></form><br></td></tr></table>";
}
if ($acceso5b) { // Si pulso en Inserta Tarjeta muestra el formulario para insertar tarjeta
    echo "<table><tr><td style='padding: 10px'><form action='Index.php' method='post'>
    <span>Nombre y Apellidos:</span><br><br><textarea name='nombreyapellidos' cols='70' rows='1'></textarea><br>
    <span>Dirección:</span><br><br><textarea name='direccion' cols='70' rows='1'></textarea><br>
    <span>Población:</span><br><br><textarea name='poblacion' cols='70' rows='1'></textarea><br>
    <span>Provincia:</span><br><br><textarea name='provincia' cols='70' rows='1'></textarea><br>
    <br><span>Código Postal:</span> <input type='number' name='codigopostal'></td>
    <td style='padding: 10px'><img src='Imagenes/Tarjeta-American-Express.jpg' id='logo2'>
    <img src='Imagenes/Tarjeta-MasterCard.png' id='logo2'><img src='Imagenes/Tarjeta-Vista.png' id='logo2'>
    <br><br><span>Número De Tarjeta:</span> <input type='number' name='numerotarjeta'><br><br>
    <span>Fecha De Caducidad (mes/año):</span> <input type='number' min='1' max='12' name='mes'> , 
    <input type='number' min='2022' name='ano'><br><br><span>Telefono de Contacto (Opcional):</span> 
    <input type='tel' name='telefono'></td></tr><tr><td colspan='2'><span>Esta operación no sera anotada en la tarjeta 
    hasta la confirmacion de la compra de los productos</span></td></tr><tr>
    <input type='hidden' name='usuariotarjeta' value='" . $_SESSION["user"] . "'><td style='padding: 10px'>
    <input type='submit' value='Insertar' name='insertatarjeta' id='continuar'></form></td><td style='padding: 10px'>
    <form action='Index.php' method='post'><input type='submit' value='Selecionar Tarjeta' name='comprar'></form>
    </td></tr></table>";
}
if ($acceso6) { // Si pulso en Continuar muestra el formulario para finalizar pedido
    echo "<table style='border: 1px solid black; font-weight: bold'><tr><form action='Index.php' method='post'>";
    foreach ($vectorct as $reg) {
        echo "<input type='text' hidden='hidden' name='usuariotarjeta' value='" . $_SESSION["user"] . "'>";
    }
    foreach ($vectorctp as $reg2) {
        echo "<td id='pagousu'><span>Usuario:</span> " . $_SESSION["user"] . "<span><br>Nombre y Apellidos:</span> "
        . $reg2["nombreyapellidos"] . "</td><td id='pagousu' colspan='2'><span>Dirección:</span> ". $reg2["direccion"]
        . "<span><br>Población:</span> " . $reg2["poblacion"] . "</td><td id='pagousu'><span>Provincia:</span> "
        . $reg2["provincia"] . "<span><br>Código Postal:</span> " . $reg2["codigopostal"] . "</td><td id='pagousu'>
        <span>Numero De Tarjeta: </span> " . $reg2["numerotarjeta"] . "<span><br>Fecha De Caducidad:</span> "
        . $reg2["mes"] . "/" . $reg2["ano"] . "</td><input type='number' hidden='hidden' name='numerotarjeta' 
        value='" . $reg2["numerotarjeta"] . "'><input type='number' hidden='hidden' name='idpago' value='"
        . $reg2["idpago"] . "'>";
    }
    echo "<tr style='border: 1px solid black; text-decoration: underline'><td style='padding: 10px'>Nombre</td>
    <td>Imagen</td><td>Cantidad</td><td>Precio</td><td>Total Producto</td><tr>";
    foreach ($vectorc as $reg2) {
        echo "<tr style='border: 1px solid black'><td id='nombreprod'><span>" . $reg2['subtipoproducto'] .
        ":</span> " . $reg2['nombreproducto'] . "</td><td style='padding: 10px'><img src='imagenes/"
        . $reg2['imagenproducto'] . "' width='150px'></td><td>" . $reg2['cantidadproducto'] . "</td><td>"
        . $reg2['precioproducto'] . " €</td><td>" . $reg2['totalproducto'] . " €</td></tr>";
    }
    foreach ($totalprecio as $totalpreciop) {
        echo "<tr><td style='text-align: right; padding: 10px' colspan='4'><span>Total Gasto De Los Productos -></span>
        </td><td align='center' style='font-weight: bold; background-color: white'>" . $totalpreciop . " €</td></tr>
        <input type='number' hidden='hidden' name='totalgastocesta' value='" . $totalpreciop . "'>";
    }
    // Si pulso en Descargar Factura se cargará el pago y se descarga el archivo de la factura
    echo "</tr></table><table><tr><td style='padding: 10px' colspan='5'><span>Primero pulsa en Descargar Factura para 
    descargar el archivo de la factura y después pulsa en Finalizar para tramitar el pedido</span></td></tr><tr>
    <td style='padding: 10px'><input type='submit' value='Descargar Factura' name='descargafactura'></form></td>
    <td style='padding: 10px' colspan='2'><form action='Index.php' method='post'>";
    foreach ($vectorc as $reg2) {
        echo "<input type='number' hidden='hidden' name='idproductocesta' value='" . $reg2['idproducto'] . "'>
        <input type='number' hidden='hidden' name='cantidadproductocesta' value='" . $reg2['cantidadproducto'] . "'>";
    }
    // Si pulso en Finalizar se actualiza la cantidad de esos productos de la tienda y los elimino de su cesta
    // Si pulso en Cambiar Tarjeta se muestra el formulario para ver el número de la tarjeta
    echo "<input type='submit' value='Finalizar' name='finaliza'></form></td><td style='padding: 10px' colspan='2'>
    <form action='Index.php' method='post'><input type='submit' value='Cambiar Tarjeta' name='comprar'></form>
    </td></tr></table>";
}
?>