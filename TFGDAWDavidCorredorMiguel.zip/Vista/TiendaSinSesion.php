<?php
if ($acceso0) { // Página de Inicio Sin Sesión
    echo "<table><tr><td><div class='col-md-2' style='border-right: 1px solid black'>
          <h3 style='text-decoration: underline'>Subcategorias De Productos</h3>";
    foreach ($subtipos as $subtipop) {
        echo "<form action='Index.php?subtipo=$subtipop' method='post'><br>
        <input type='submit' value='$subtipop' id='subtipo' name='buscarsubtipo0'></form>";
    }
    echo "</div>";
    foreach ($vectorp0 as $reg2) {
        echo "<div class='col-md-3'><br><br><section class='section'><img src='imagenes/" . $reg2['imagen'] .
        "' width='200px' name='imagencesta'><form action='Index.php?nombre=" . $reg2['nombre'] .
        "' method='post'><br><input type='submit' value='" . $reg2['nombre'] . "' class='nombre' name='detalles0'><br>
        </form><h3>" . $reg2['precio'] . " €</h3><br></section></div>";
    }
}
if ($acceso2a) { // Detalles del producto Sin Conexion
    echo "<table>";
    if (isset($detallesproducto)) {
        echo "<tr><td><img src='imagenes/" . $detallesproducto['imagen'] . "' name='imagencesta'></td>
        <td colspan='2' style='padding: 20px'><h1 id='nombreprod'>" . $detallesproducto['nombre'] . "</h1><br>
        <span>Selecciona Cantidad Antes De Añadir a La Cesta</span></div><br><br><span>Disponible:</span> "
        . $detallesproducto['cantidad'] . " unidades<br><span>Cantidad A Elegir:</span> 
        <input type='number' min='1' max='" . $detallesproducto['cantidad'] . "'name='cantidadcesta' id='prod' 
        disabled><br><span>Precio:</span> " . $detallesproducto['precio'] . " €<br><br>
        <form action='Index.php' method='post'><input type='submit' name='iniciasesion' value='Añadir A La Cesta'>
        </form></form><br><span>Detalles Técnicos<br></span>" . $detallesproducto['descripcion'] . "<br><br></td></tr>
        <footer><br><table><tr><td><h4>Comentarios Del Producto</h4><div style='margin: 10px; padding: 10px'>";
        foreach ($vectorcomtp as $reg2) {
            echo "<img src='imagenesusuarios/" . $reg2["imagenusuario"] . "' style='width: 40px; border-radius: 30px'> 
            <span>" . $reg2['nombreusuario'] . "</span><br><span>Fecha:</span> " . $reg2['fecha'] .
            "<br><span>Valoración:</span> " . $reg2['valoracion'] . "<br><span>Comentario:</span><br>
            <textarea cols='30' rows='1' disabled>" . $reg2['comentario'] . "</textarea><br>";
        }
        echo "<form action='Index.php?nombre=" . $detallesproducto['nombre'] . "' method='post'>
        <input type='submit' value='Ver Mas Comentarios' name='comentariosp0'><br><br></form></div></td>
        <td><h4>Añade Un Comentario y Valoración Sobre El Producto:</h4><form action='Index.php' method='post'>
        <span>Valoración (1-10):</span> <input type='number' min='1' max='10' name='valoraciontienda' disabled><br><br>
        <textarea name='comentariotienda' cols='100' rows='5' disabled></textarea><br>
        <input type='submit' name='iniciasesion' value='Enviar Comentario Producto'></form><br></td></tr></table>";
    }
}
if ($acceso3a) { // Producto buscado Sin Conexion
    if ($paginaactual == 0) {
        $paginaactual = 1;
    }
    echo "<table><tr><td><div class='col-md-2' style='padding: 20px; border-right: 1px solid black'>
    <h3 style='text-decoration: underline'>Subcategorias De Productos</h3>";
    foreach ($subtipos as $subtipop) {
        echo "<form action='Index.php?subtipo=$subtipop' method='post'><br>
        <input type='submit' value='$subtipop' id='subtipo' name='buscarsubtipo0'></form>";
    }
    echo "</div>";
    foreach ($vector as $reg2) {
        echo "<div class='col-md-3'><br><br><section class='section'><img src='imagenes/" . $reg2['imagen'] .
        "' width='200px' name='imagencesta'><form action='Index.php?nombre=" . $reg2['nombre'] . "' method='post'><br>
        <input type='submit' value='" . $reg2['nombre'] . "' class='nombre' name='detalles0'><br></form><h3>"
        . $reg2['precio'] . " €</h3><br></section></div>";
    }
    echo "</td></tr></table>";
}
?>