<?php
if ($crearsesion) { // Formulario para crear usuario
    ?>
    <table align="center">
        <tr>
            <td colspan="3">
                <h1>CREAR USUARIO</h1>
                <form action="<?php $_SERVER["PHP_SELF"] ?>" method="post" enctype="multipart/form-data">
            </td>
        </tr>
        <tr>
            <td colspan="3"><span>Usuario:</span></td>
        </tr>
        <tr>
            <td colspan="3"><input type="text" name="userR"></td>
        </tr>
        <tr>
            <td colspan="3"><span>Contraseña:</span></td>
        </tr>
        <tr>
            <td colspan="3"><input type="password" name="passR"></td>
        </tr>
        <tr>
            <td colspan="3"><span>Imagen De Usuario:</span></td>
        </tr>
        <tr>
            <td colspan="3" align="center"><input type="file" name="newimagenusuario"></td>
        </tr>
        <tr>
            <td><input type="submit" value="Registrarse" name="registrar"></form></td>
            <td>
                <form action='Index.php?login' method='post'>
                    <input type='submit' name='iniciasesion' value='Iniciar Sesion'></form>
            </td>
            <td>
                <form action='Index.php' method='post'><input type='submit' value='Volver A Inicio'></form>
            </td>
        </tr>
    </table>
    <?php
}
?>