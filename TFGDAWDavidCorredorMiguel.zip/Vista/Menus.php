<?php
if ($header0) { // Header Sin Sesión
    echo "<table id='menu'><tr><td><img src='imagenes/LogoTienda.png' id='logo'><h4>Productos Tecnológicos</h4>
    <td><form action='Index.php' method='post'><br><input type='submit' value='Inicio'><br><br></form></td>
    <td><form action='Index.php' method='post'><select name='tipovalor'><option>Tipo De Producto: </option>";
    foreach ($tipos as $tipop) {
        echo "<option value='$tipop'>$tipop</option>";
    }
    echo "</select><input type='submit' name='buscar0'></form></td><td><form action='Index.php' method='post'>
    <input type='submit' name='iniciasesion' value='Cesta'></form></td><td><form action='Index.php?login' method='post'>
    <input type='submit' name='iniciasesion' id='botonesazules' value='Iniciar Sesión'></form></td></tr></table>";
}
if ($header1) { // Header Con Sesión
    if (isset($_COOKIE["user"])) {
        if ($tipousuario == "usuario") {
            echo "<table id='menu'><tr><td width='20%'><img src='imagenes/LogoTienda.png' 
            id='logo'><br><h4>Productos Tecnológicos</h4></td><td><form action='Index.php' method='post'><br>
            <input type='submit' value='Inicio'><br><br></form></td><td><form action='Index.php' method='post'>
            <select name='tipovalor'><option>Tipo De Producto: </option>";
            foreach ($tipos as $tipop) {
                echo "<option value='$tipop'>$tipop</option>";
            }
            echo "</select><input type='submit' name='buscar'></form></td>
            <td><form action='Index.php' method='post'><input type='submit' name='vercesta' value='Cesta'>
            </form></td><td width='20%'><b>" . $_COOKIE["user"] . "</b> ";
        } else {
            echo "<table id='menu'><tr><td width='20%'><img src='imagenes/LogoTienda.png' 
            id='logo'><br><h4>Productos Tecnológicos</h4></td><td><form action='Index.php' method='post'><br>
            <input type='submit' value='Inicio'><br><br></form></td><td><form action='Index.php' method='post'>
            <select name='tipovalor'><option>Tipo De Producto: </option>";
            foreach ($tipos as $tipop) {
                echo "<option value='$tipop'>$tipop</option>";
            }
            echo "</select><input type='submit' name='buscar'></form></td>
            <td><form action='Index.php' method='post'> <input type='submit' name='vercesta' value='Cesta'>
            </form></td><td width='20%'><b>Administrador - " . $_COOKIE["user"] . "</b> ";
        }
        foreach ($imagenusuarios as $imagenusuario) {
            echo "<img src='imagenesusuarios/" . $imagenusuario["imagenusuario"] . "' id='imgusu'>";
        }
        echo "<br><br><form action='Index.php' method='post'>
        <input type='submit' value='Cambiar Imagen' name='cambiaimagen'></form><br>
        <a href='Index.php?logout=1' id='botonesazules'>Cerrar Sesion</a><br><br></td></tr></table>";
    } else if (isset($_SESSION["user"])) {
        if ($tipousuario == "usuario") {
            echo "<table id='menu'><tr><td width='20%'><img src='imagenes/LogoTienda.png' 
            id='logo'><br><h4>Productos Tecnológicos</h4></td><td><form action='Index.php' method='post'><br>
            <input type='submit' value='Inicio'><br><br></form></td><td><form action='Index.php' method='post'>
            <select name='tipovalor'><option>Tipo De Producto: </option>";
            foreach ($tipos as $tipop) {
                echo "<option value='$tipop'>$tipop</option>";
            }
            echo "</select><input type='submit' name='buscar'></form></td>
            <td><form action='Index.php' method='post'><input type='submit' name='vercesta' value='Cesta'>
            </form></td><td width='20%'><b>" . $_SESSION["user"] . "</b> ";
        } else {
            echo "<table id='menu'><tr><td width='20%'><img src='imagenes/LogoTienda.png' 
            id='logo'><br><h4>Productos Tecnológicos</h4></td><td><form action='Index.php' method='post'><br>
            <input type='submit' value='Inicio'><br><br></form></td><td><form action='Index.php' method='post'>
            <select name='tipovalor'><option>Tipo De Producto: </option>";
            foreach ($tipos as $tipop) {
                echo "<option value='$tipop'>$tipop</option>";
            }
            echo "</select><input type='submit' name='buscar'></form></td>
            <td><form action='Index.php' method='post'> <input type='submit' name='vercesta' value='Cesta'>
            </form></td><td width='20%'><b>Administrador - " . $_SESSION["user"] . "</b> ";
        }
        foreach ($imagenusuarios as $imagenusuario) {
            echo "<img src='imagenesusuarios/" . $imagenusuario["imagenusuario"] . "' id='imgusu'>";
        }
        echo "<br><br><form action='Index.php' method='post'>
        <input type='submit' value='Cambiar Imagen' name='cambiaimagen'></form><br>
        <a href='Index.php?logout=1' id='botonesazules'>Cerrar Sesion</a><br><br></td></tr></table>";
    }
}
?>