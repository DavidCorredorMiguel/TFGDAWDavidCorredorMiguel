-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-04-2022 a las 10:45:43
-- Versión del servidor: 10.4.19-MariaDB
-- Versión de PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tfgdavidc`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carritotienda`
--

CREATE TABLE `carritotienda` (
  `idcarrito` int(11) NOT NULL,
  `nombreusuario` varchar(200) NOT NULL,
  `idproducto` int(11) NOT NULL,
  `tipoproducto` varchar(200) NOT NULL,
  `subtipoproducto` varchar(250) NOT NULL,
  `nombreproducto` varchar(200) NOT NULL,
  `cantidadproducto` int(11) NOT NULL,
  `precioproducto` decimal(6,2) NOT NULL,
  `imagenproducto` varchar(200) NOT NULL,
  `totalproducto` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `carritotienda`
--

INSERT INTO `carritotienda` (`idcarrito`, `nombreusuario`, `idproducto`, `tipoproducto`, `subtipoproducto`, `nombreproducto`, `cantidadproducto`, `precioproducto`, `imagenproducto`, `totalproducto`) VALUES
(5, 'luffy', 14, '', 'Impresora Laser', 'Brother HL1210W', 1, '123.28', 'Brother HL1210W.jpg', '123.28'),
(83, 'ace', 19, '', 'Smart TV FULL HD', 'Philips 24PFS6805', 2, '170.44', 'Philips 24PFS6805.jpg', '340.88'),
(84, 'ace', 9, '', 'PC Portatil', 'Asus ZenBook 14 Ultralight UX435EAL-KC096T', 1, '1350.26', 'Asus ZenBook 14 Ultralight UX435EAL-KC096T.jpg', '1350.26'),
(85, 'ann', 11, '', 'Portatil Gaming', 'MSI Alpha 15 A4DEK-006XES', 1, '942.24', 'MSI Alpha 15 A4DEK-006XES.jpg', '942.24'),
(86, 'ann', 20, '', 'Smart TV FULL HD', 'Samsung UE32T5305', 2, '249.01', 'Samsung UE32T5305.jpg', '498.02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentariosproductos`
--

CREATE TABLE `comentariosproductos` (
  `idcomentario` int(11) NOT NULL,
  `nombreproducto` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `nombreusuario` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `imagenusuario` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `comentario` text CHARACTER SET utf8 DEFAULT NULL,
  `valoracion` int(2) DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `comentariosproductos`
--

INSERT INTO `comentariosproductos` (`idcomentario`, `nombreproducto`, `nombreusuario`, `imagenusuario`, `comentario`, `valoracion`, `fecha`) VALUES
(1, 'Lenovo IdeaCentre 5 14IMB05', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(2, 'Lenovo IdeaCentre 5 14IMB05', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(3, 'Lenovo IdeaCentre 5 14IMB05', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(4, 'HP M01-F1003NS', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(5, 'HP M01-F1003NS', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(6, 'HP M01-F1003NS', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(7, 'Asus S300MA-310100018D', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(8, 'Asus S300MA-310100018D', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(9, 'Asus S300MA-310100018D', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(10, 'HP Pavilion Gaming TG01-1049ns', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(11, 'HP Pavilion Gaming TG01-1049ns', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(12, 'HP Pavilion Gaming TG01-1049ns', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(13, 'Lenovo IdeaCentre 510S-15ICB', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(14, 'Lenovo IdeaCentre 510S-15ICB', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(15, 'Lenovo IdeaCentre 510S-15ICB', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(16, 'MSI MEG Trident X 10TD 1623XIB', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(17, 'MSI MEG Trident X 10TD 1623XIB', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(18, 'MSI MEG Trident X 10TD 1623XIB', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(19, 'Lenovo IdeaPad 1 11IGL05', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(20, 'Lenovo IdeaPad 1 11IGL05', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(21, 'Lenovo IdeaPad 1 11IGL05', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(22, 'HP 250 G7 Intel Core i5-1035G1', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(23, 'HP 250 G7 Intel Core i5-1035G1', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(24, 'HP 250 G7 Intel Core i5-1035G1', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(25, 'Asus ZenBook 14 Ultralight UX435EAL-KC096T', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(26, 'Asus ZenBook 14 Ultralight UX435EAL-KC096T', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(27, 'Asus ZenBook 14 Ultralight UX435EAL-KC096T', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(28, 'Asus TUF Gaming FX505DT-HN540', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(29, 'Asus TUF Gaming FX505DT-HN541', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(30, 'Asus TUF Gaming FX505DT-HN542', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(31, 'MSI Alpha 15 A4DEK-006XES', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(32, 'MSI Alpha 15 A4DEK-006XES', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(33, 'MSI Alpha 15 A4DEK-006XES', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(34, 'MSI GL65 Leopard 10SEK-241XES', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(35, 'MSI GL65 Leopard 10SEK-241XES', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(36, 'MSI GL65 Leopard 10SEK-241XES', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(37, 'HP Officejet Pro 6230', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(38, 'HP Officejet Pro 6231', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(39, 'HP Officejet Pro 6232', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(40, 'Brother HL1210W', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(41, 'Brother HL1210W', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(42, 'Brother HL1210W', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(43, 'HP LaserJet Pro M15w', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(44, 'HP LaserJet Pro M15w', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(45, 'HP LaserJet Pro M15w', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(46, 'Anet A8', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(47, 'Anet A9', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(48, 'Anet A10', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(49, 'Creality CR-6 SE', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(50, 'Creality CR-6 SE', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(51, 'Creality CR-6 SE', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(52, 'Bresser Rex II', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(53, 'Bresser Rex II', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(54, 'Bresser Rex II', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(55, 'Philips 24PFS6805', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(56, 'Philips 24PFS6806', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(57, 'Philips 24PFS6807', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(58, 'Samsung UE32T5305', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(59, 'Samsung UE32T5306', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(60, 'Samsung UE32T5307', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(61, 'LG 32LM6300PLA', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(62, 'LG 32LM6300PLA', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(63, 'LG 32LM6300PLA', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(64, 'Samsung UE43AU7105KXXC', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(65, 'Samsung UE43AU7105KXXC', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(66, 'Samsung UE43AU7105KXXC', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(67, 'Xiaomi Mi TV 4S', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(68, 'Xiaomi Mi TV 4S', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(69, 'Xiaomi Mi TV 4S', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(70, 'LG 55NANO813NA', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(71, 'LG 55NANO813NA', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(72, 'LG 55NANO813NA', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(73, 'LG 55NANO956NA', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(74, 'LG 55NANO956NA', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(75, 'LG 55NANO956NA', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(76, 'Samsung QE65Q950TS', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(77, 'Samsung QE65Q950TS', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(78, 'Samsung QE65Q950TS', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(79, 'LG 65NANO956NA', 'luffy', 'luffy.png', 'Producto Perfecto', 10, '2021-06-23 08:54:30'),
(80, 'LG 65NANO956NA', 'ace', 'ace.png', 'Producto Con Muy Buen Estado', 8, '2021-06-23 08:59:01'),
(81, 'LG 65NANO956NA', 'chopper', 'chopper.png', 'Producto Con Buen Estado', 6, '2021-06-23 09:01:10'),
(82, 'Lenovo IdeaCentre 5 14IMB05', 'lucci', 'lucci.png', 'Producto En Perfecto Estado', 10, '2021-08-09 09:28:12'),
(83, 'HP Pavilion Gaming TG01-1049ns', 'lucci', 'lucci.png', 'Producto En Estado Perfecto', 10, '2021-08-09 09:39:51'),
(84, 'HP M01-F1003NS', 'ace', 'ace.png', 'Producto En Estado Perfecto', 10, '2021-08-09 09:53:48');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentariostienda`
--

CREATE TABLE `comentariostienda` (
  `idcomentario` int(11) NOT NULL,
  `nombreusuario` varchar(200) NOT NULL,
  `imagenusuario` varchar(200) NOT NULL,
  `comentario` text NOT NULL,
  `valoracion` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `comentariostienda`
--

INSERT INTO `comentariostienda` (`idcomentario`, `nombreusuario`, `imagenusuario`, `comentario`, `valoracion`, `fecha`) VALUES
(1, 'luffy', 'luffy.png', 'Todo Perfecto', 10, '2021-06-23 08:54:30'),
(2, 'ace', 'ace.png', 'Todo Bien', 8, '2021-06-23 08:59:01'),
(3, 'chopper', 'chopper.png', 'Bien', 6, '2021-06-23 09:01:10'),
(4, 'ace', 'ace.png', 'Servicio Perfecto', 10, '2021-08-12 09:28:10'),
(5, 'ann', 'ann.png', 'Buen Servicio', 6, '2022-02-25 10:18:40');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facturas`
--

CREATE TABLE `facturas` (
  `idfactura` int(11) NOT NULL,
  `idpago` int(11) NOT NULL,
  `subtipoproducto` varchar(250) NOT NULL,
  `nombreproducto` varchar(250) NOT NULL,
  `cantidadproducto` varchar(250) NOT NULL,
  `precioproducto` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `infogeneral`
--

CREATE TABLE `infogeneral` (
  `email` varchar(200) NOT NULL,
  `telefonocontacto` int(9) NOT NULL,
  `direccion` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `infogeneral`
--

INSERT INTO `infogeneral` (`email`, `telefonocontacto`, `direccion`) VALUES
('productostecnologia@gmail.com', 678012358, 'Calle Mayor Nº 18 5A, Madrid');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `idpago` int(11) NOT NULL,
  `nombreusuario` varchar(200) NOT NULL,
  `nombreyapellidos` varchar(250) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `poblacion` varchar(250) NOT NULL,
  `provincia` varchar(250) NOT NULL,
  `codigopostal` int(5) NOT NULL,
  `numerotarjeta` int(20) NOT NULL,
  `mes` int(2) NOT NULL,
  `ano` year(4) NOT NULL,
  `telefono` int(9) DEFAULT NULL,
  `totalgasto` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`idpago`, `nombreusuario`, `nombreyapellidos`, `direccion`, `poblacion`, `provincia`, `codigopostal`, `numerotarjeta`, `mes`, `ano`, `telefono`, `totalgasto`) VALUES
(1, 'ace', 'David Corredor Miguel', 'Calle Mayor Numero 31 1B', 'Alcorcon', 'Madrid', 28921, 236492361, 12, 2026, 678009156, '1691.14'),
(2, 'ace', 'David Corredor Miguel', 'Calle Mayor Numero 31 1B', 'Alcorcon', 'Madrid', 28921, 236491342, 2, 2021, 0, '1691.14'),
(227, 'ace', 'David Corredor Miguel', 'Calle Mayor Numero 31 1B', 'Alcorcon', 'Madrid', 28921, 894282, 6, 2025, 667800915, '2166.62'),
(229, 'ann', 'a', 'b', 'c', 'd', 28823, 2898982, 1, 2024, 667083629, '1440.26'),
(230, 'david1', 'suigsgdfskghkf', 'sfgkldfglkdfk', 'sfghdkjf', 'sfdsjfgkjsf', 25632, 2894282, 1, 2029, 62424224, '1265.35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productostienda`
--

CREATE TABLE `productostienda` (
  `idproducto` int(11) NOT NULL,
  `tipo` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `subtipo` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `nombre` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `descripcion` text CHARACTER SET utf8 DEFAULT NULL,
  `cantidad` int(3) DEFAULT NULL,
  `precio` decimal(6,2) DEFAULT NULL,
  `imagen` varchar(250) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productostienda`
--

INSERT INTO `productostienda` (`idproducto`, `tipo`, `subtipo`, `nombre`, `descripcion`, `cantidad`, `precio`, `imagen`) VALUES
(1, 'Ordenadores', 'PC Sobremesa', 'Lenovo IdeaCentre 5 14IMB05', 'Procesador Intel Core i5-10400 (6C / 12T, 2.9 / 4.3GHz, 12MB) Memoria 2x 4GB UDIMM DDR4-2933 Disco duro 512GB SSD M.2 2242 PCIe NVMe Almacenamiento óptico NO Tarjeta gráfica Integrated Intel UHD Graphics 630 Conectividad LAN 10/100/1000 11ac, 2x2 + BT5.0 Conexiones 2x USB 3.2 Gen 1 1x USB-C 3.2 Gen 1 1x headphone / microphone combo jack (3.5mm) 1x card reader 4x USB 2.0 1x Ethernet (RJ-45) 1x HDMI 1.4b 1x VGA 1x line-out (3.5mm) Sistema operativo SIN SISTEMA OPERATIVO Dimensiones 145 x 284.6 x 340 mm Peso 5.4Kg Color Mineral Grey', 500, '448.99', 'Lenovo IdeaCentre 5 14IMB05.jpg'),
(2, 'Ordenadores', 'PC Sobremesa', 'HP M01-F1003NS', 'Procesador Fabricante de procesador: Intel Modelo del procesador: i5-10400 Familia de procesador: Intel® Core™ i5 de 10ma Generación Número de núcleos de procesador: 6 Frecuencia del procesador: 2,9 GHz Frecuencia del procesador turbo: 4,3 GHz Caché del procesador: 12 MB Número de procesadores instalados: 1 Memoria Memoria interna: 8 GB Tipo de memoria interna: DDR4-SDRAM Disposición de la memoria: 1 x 8 GB Ranuras de memoria: 2x DIMM Velocidad de memoria del reloj: 2666 MHz Medios de almacenaje Capacidad total de almacenaje: 1512 GB Unidad de almacenamiento: HDD+SSD Tipo de unidad óptica: No Número de unidades de almacenamiento instaladas: 2 Capacidad total de HDD: 1000 GB Número de HDDs instalados: 1 Capacidad del HDD: 1000 GB Interfaz del HDD: SATA Velocidad de rotación del HDD: 7200 RPM Capacidad total de SSD: 512 GB Número de unidades SSD instalados: 1 SDD, capacidad: 512 GB Interfaces del SDD: PCI Express Tarjeta de lectura integrada: Si Gráficos Adaptador de gráficos discreto: No Modelo de adaptador de gráficos discretos: No disponible Adaptador gráfico incorporado: Si Modelo de adaptador gráfico incorporado: Intel® UHD Graphics 630 Conexión Ethernet: Si Ethernet LAN, velocidad de transferencia de datos: 10,100,1000 Mbit/s Wifi: Si Estándar Wi-Fi: Wi-Fi 5 (802.11ac) Wi-Fi estándares: Wi-Fi 5 (802.11ac) Tipo de antena: 1x1 Bluetooth: Si Versión de Bluetooth: 4.2 Puertos e Interfaces Cantidad de puertos USB 2.0: 4 Cantidad de puertos tipo A USB 3.2 Gen 1 (3.1 Gen 1): 2 Cantidad de puertos tipo A USB 3.2 Gen 2 (3.1 Gen 2): 2 Cantidad de puertos VGA (D-Sub): 1 Puerto DVI: No Número de puertos HDMI: 1 Versión HDMI: 1.4 Ethernet LAN (RJ-45) cantidad de puertos: 1 Micrófono, jack de entrada: Si Salida de línea: Si Entrada de línea: Si Combo de salida de auriculares / micrófono del puerto: Si Ranuras de expansión Ranuras x1 PCI Express: 1 Ranuras x16 PCI Express: 1 Diseño Tipo de chasis: Tower Colocación soportada: Vertical Color del producto: Negro País de origen: China Desempeño Tipo de producto: PC Software Sistema operativo instalado: FreeDOS Características especiales Segmento HP: Hogar Control de energía Fuente de alimentación: 310 W Peso y dimensiones Ancho: 155,4 mm Profundidad: 303 mm Altura: 337,4 mm Peso: 4,71 kg Ancho del paquete: 499 mm Profundidad del paquete: 400 mm Altura del paquete: 287 mm Peso del paquete: 8,2 kg Contenido del embalaje Pantalla incluida: No', 500, '529.00', 'HP M01-F1003NS.jpg'),
(3, 'Ordenadores', 'PC Sobremesa', 'Asus S300MA-310100018D', 'Procesador Fabricante de procesador: Intel Modelo del procesador: i3-10100 Familia de procesador: Intel® Core™ i3 de 10ma Generación Número de núcleos de procesador: 4 Frecuencia del procesador: 3,6 GHz Frecuencia del procesador turbo: 4,3 GHz Caché del procesador: 6 MB Memoria Memoria interna: 8 GB Tipo de memoria interna: DDR4-SDRAM Memoria interna máxima: 64 GB Medios de almacenaje Capacidad total de almacenaje: 512 GB Unidad de almacenamiento: SSD Tipo de unidad óptica: No Capacidad total de SSD: 512 GB Número de unidades SSD instalados: 1 SDD, capacidad: 512 GB Interfaces del SDD: NVMe,PCI Express 3.0 Factor de forma de disco SSD: M.2 Tarjeta de lectura integrada: No Gráficos Adaptador de gráficos discreto: No Modelo de adaptador de gráficos discretos: No disponible Adaptador gráfico incorporado: Si Modelo de adaptador gráfico incorporado: Intel® UHD Graphics 630 Conexión Ethernet: Si Ethernet LAN, velocidad de transferencia de datos: 10,100,1000 Mbit/s Wifi: Si Estándar Wi-Fi: Wi-Fi 5 (802.11ac) Wi-Fi estándares: Wi-Fi 5 (802.11ac) Tipo de antena: 1x1 Bluetooth: Si Versión de Bluetooth: 4.0 Puertos e Interfaces Cantidad de puertos USB 2.0: 2 Cantidad de puertos tipo A USB 3.2 Gen 1 (3.1 Gen 1): 2 Cantidad de puertos VGA (D-Sub): 1 Puerto DVI: No Número de puertos HDMI: 1 Ethernet LAN (RJ-45) cantidad de puertos: 1 Micrófono, jack de entrada: Si Salidas para auriculares: 1 Diseño Tipo de chasis: Mini Tower Número de puertos 3.5\": 1 Número de bahías 2.5\'\': 1 Ranura para cable de seguridad: Si Tipo de ranura de bloqueo del cable: Kensington Color del producto: Negro Año del modelo: 2020 Desempeño Chipset: Intel H410 Protección mediante contraseña: Si Protección con contraseña: BIOS, Unidad de disco duro, Usuario Tipo de producto: PC Módulo de plataforma confiable (TPM): Si Software Sistema operativo instalado: Endless OS Características especiales del procesador Intel® 64: Si Tecnología SpeedStep mejorada de Intel: Si Opciones integradas disponibles: No Tecnología Intel® Clear Video: Si VT-x de Intel® con Extended Page Tables (EPT): Si Estados de inactividad: Si Programa de Plataforma de Imagen Estable de Intel® (SIPP): No Tecnología Trusted Execution de Intel®: No Execute Disable Bit: Si Extensiones de protección de software Intel® (Intel® SGX): Si Configuración de CPU (máximo): 1 Tecnología de virtualización de Intel® para E / S dirigida (VT-d): Si Tecnología de virtualización Intel® (VT-x): Si Control de energía Fuente de alimentación: 200 W Certificación 80 PLUS: 80 PLUS Peso y dimensiones Ancho: 160 mm Profundidad: 307 mm Altura: 373 mm Peso: 5,59 kg Contenido del embalaje Pantalla incluida: No', 498, '369.99', 'Asus S300MA-310100018D.jpg'),
(4, 'Ordenadores', 'Sobremesa Gaming', 'HP Pavilion Gaming TG01-1049ns', 'Procesador Fabricante de procesador: Intel Modelo del procesador: i7-10700F Familia de procesador: Intel® Core™ i7 de 10ma Generación Número de núcleos de procesador: 8 Frecuencia del procesador: 2,9 GHz Frecuencia del procesador turbo: 4,7 GHz Caché del procesador: 16 MB Tipo de cache en procesador: L3 Número de filamentos de procesador: 16 Memoria Memoria interna: 16 GB Tipo de memoria interna: DDR4-SDRAM Disposición de la memoria: 1 x 16 GB Ranuras de memoria: 2x DIMM Velocidad de memoria del reloj: 2933 MHz ECC: No Medios de almacenaje Capacidad total de almacenaje: 1512 GB Unidad de almacenamiento: HDD+SSD Tipo de unidad óptica: No Número de unidades de almacenamiento instaladas: 2 Capacidad total de HDD: 1000 GB Número de HDDs instalados: 1 Capacidad del HDD: 1000 GB Interfaz del HDD: SATA Velocidad de rotación del HDD: 7200 RPM Capacidad total de SSD: 512 GB Número de unidades SSD instalados: 1 SDD, capacidad: 512 GB Interfaces del SDD: NVMe Factor de forma de disco SSD: M.2 Tarjeta de lectura integrada: Si Gráficos Adaptador de gráficos discreto: Si Fabricante de GPU (unidad de procesamiento gráfico) externa: NVIDIA Modelo de adaptador de gráficos discretos: NVIDIA GeForce GTX 1660 SUPER Tipo de memoria de gráficos discretos: GDDR6 Capacidad memoria de adaptador gráfico: 6 GB Conexión Ethernet: Si Ethernet LAN, velocidad de transferencia de datos: 10,100,1000 Mbit/s Wifi: Si Estándar Wi-Fi: Wi-Fi 6 (802.11ax) Wi-Fi estándares: Wi-Fi 6 (802.11ax) Fabricante del controlador WLAN: Intel Modelo de controlador WLAN: Intel Wi-Fi 6 AX201 Tipo de antena: 2x2 Bluetooth: Si Versión de Bluetooth: 5.0 Miracast: Si Puertos e Interfaces Cantidad de puertos USB 2.0: 4 Cantidad de puertos tipo A USB 3.2 Gen 1 (3.1 Gen 1): 4 Cantidad de puertos tipo C USB 3.2 Gen 1 (3.1 Gen 1): 1 Puerto DVI: No Ethernet LAN (RJ-45) cantidad de puertos: 1 Micrófono, jack de entrada: Si Salida de línea: Si Entrada de línea: Si Combo de salida de auriculares / micrófono del puerto: Si Ranuras de expansión PCI Express x1 (Gen 1.x) ranuras: 1 PCI Express x16 Gen (1.x) ranuras: 1 Entradas Mini PCI Express: 2 Diseño Tipo de chasis: Mini Tower Colocación soportada: Vertical Ranura para cable de seguridad: Si Tipo de ranura de bloqueo del cable: Kensington Color del producto: Negro País de origen: China Desempeño Posicionamiento de mercado: Juego Chipset: Intel H470 Canales de salida de audio: 5.1 canales Tipo de producto: PC Software Sistema operativo instalado: FreeDOS Características especiales del procesador Intel® 64: Si Tecnología SpeedStep mejorada de Intel: Si Opciones integradas disponibles: No VT-x de Intel® con Extended Page Tables (EPT): Si Estados de inactividad: Si Programa de Plataforma de Imagen Estable de Intel® (SIPP): No Tecnología Trusted Execution de Intel®: No Execute Disable Bit: Si Extensiones de protección de software Intel® (Intel® SGX): Si Configuración de CPU (máximo): 1 Tecnología de virtualización de Intel® para E / S dirigida (VT-d): Si Tecnología de virtualización Intel® (VT-x): Si Características especiales Segmento HP: Hogar Control de energía Fuente de alimentación: 400 W Peso y dimensiones Ancho: 155,4 mm Profundidad: 307 mm Altura: 337,4 mm Peso: 5,96 kg Ancho del paquete: 499 mm Profundidad del paquete: 400 mm Altura del paquete: 287 mm Peso del paquete: 8,2 kg Contenido del embalaje Pantalla incluida: No', 200, '999.00', 'HP Pavilion Gaming TG01-1049ns.jpg'),
(5, 'Ordenadores', 'Sobremesa Gaming', 'Lenovo IdeaCentre 510S-15ICB', 'Procesador Intel Core i5-8400 (6C, 2.8 / 4.0GHz, 9MB) Memoria 8GBx1 DDR4-2466 Disco duro 1TB 7200rpm 3.5\" Almacenamiento óptico DVD±RW Tarjeta gráfica NVIDIA GeForce GTX 1050 Ti 4GB GDDR5 Conectividad LAN 10/100/1000 Wifi 802.11 ac Bluetooth 4.0 Conexiones 4 x USB 2.0 3 x USB 3.1 1 x DVI 1 x HDMI 1 x RJ45 1 x Displayport 1 x Headphone/Lineout 1 x Mic-in Sistema operativo SIN SISTEMA OPERATIVO Dimensiones 297 mm (D) X 344 (H) mm X 90mm (W) Peso 5.2Kg Color Negro/Plata', 198, '723.78', 'Lenovo IdeaCentre 510S-15ICB.jpg'),
(6, 'Ordenadores', 'Sobremesa Gaming', 'MSI MEG Trident X 10TD 1623XIB', 'Procesador Fabricante de procesador: Intel Modelo del procesador: i7-10700K Familia de procesador: Intel® Core™ i7 de 10ma Generación Número de núcleos de procesador: 8 Frecuencia del procesador: 3,8 GHz Frecuencia del procesador turbo: 5,1 GHz Caché del procesador: 16 MB Número de filamentos de procesador: 16 Potencia de diseño térmico configurable-baja: 95 W Frecuencia de potencia de diseño térmico configurable-baja: 3,5 GHz Memoria Memoria interna: 16 GB Tipo de memoria interna: DDR4-SDRAM Medios de almacenaje Capacidad total de almacenaje: 1000 GB Unidad de almacenamiento: SSD Tipo de unidad óptica: No Número de unidades SSD instalados: 1 SDD, capacidad: 1000 GB Memoria Intel® Optane™ instalada: No Gráficos Fabricante de GPU (unidad de procesamiento gráfico) externa: NVIDIA Modelo de adaptador de gráficos discretos: NVIDIA GeForce RTX 3070 Ventus Tipo de memoria de gráficos discretos: GDDR6 Capacidad memoria de adaptador gráfico: 8 GB NVIDIA G-SYNC: Si NVIDIA GameWorks VR: Si AMD FreeSync: Si Conexión Ethernet: Si Wifi: Si Estándar Wi-Fi: Wi-Fi 6 (802.11ax) Wi-Fi estándares: Wi-Fi 6 (802.11ax) Fabricante del controlador WLAN: Intel Modelo de controlador WLAN: Intel Wi-Fi 6 AX201 Bluetooth: Si Versión de Bluetooth: 5.1 Puertos e Interfaces Cantidad de puertos USB 2.0: 2 Cantidad de puertos tipo A USB 3.2 Gen 1 (3.1 Gen 1): 2 Cantidad de puertos Thunderbolt: 1 Cantidad de puertos Thunderbolt 3: 1 Número de puertos HDMI: 1 Versión HDMI: 1.4 Cantidad de DisplayPorts: 1 Versión de DisplayPort: 1.1a Ethernet LAN (RJ-45) cantidad de puertos: 1 Micrófono, jack de entrada: Si Salidas para auriculares: 1 Desempeño Posicionamiento de mercado: Juego Con tecnología de: MSI Listo para realidad virtual (RV): Si Chipset: Intel Z490 Factor de forma: ATX Tipo de producto: PC Software Sistema operativo instalado: Sin sistema operativo Características especiales del procesador Intel® 64: Si Tecnología SpeedStep mejorada de Intel: Si Opciones integradas disponibles: No Tecnología Intel® Clear Video: Si VT-x de Intel® con Extended Page Tables (EPT): Si Estados de inactividad: Si Programa de Plataforma de Imagen Estable de Intel® (SIPP): Si Tecnología Trusted Execution de Intel®: Si Execute Disable Bit: Si Extensiones de protección de software Intel® (Intel® SGX): Si Configuración de CPU (máximo): 1 Tecnología de virtualización de Intel® para E / S dirigida (VT-d): Si Tecnología de virtualización Intel® (VT-x): Si Control de energía Fuente de alimentación: 750 W Peso y dimensiones Ancho: 137 mm Profundidad: 410 mm Altura: 396 mm Peso: 6,55 kg Contenido del embalaje Pantalla incluida: No Ratón incluido: No Incluye teclado: No', 200, '2099.99', 'MSI MEG Trident X 10TD 1623XIB.jpg'),
(7, 'Ordenadores', 'PC Portatil', 'Lenovo IdeaPad 1 11IGL05', 'Procesador Intel® Celeron® N4020 (2C / 2T, 1.1 / 2.8GHz, 4MB) Memoria RAM 8GB Soldered DDR4-2400 Almacenamiento 64GB eMMC 5.1 Unidad óptica No Display 11.6\" HD (1366x768) TN 250nits Anti-glare, 45% NTSC Controlador gráfico Intel UHD Graphics 600 Conectividad 11ac, 2x2 + BT5.0 Cámara de portátil 0.3MP Micrófono Sí Batería Integrated 32Wh Conexiones 2x USB 3.2 Gen 1 1x HDMI 1.4 1x card reader 1x headphone / microphone combo jack (3.5mm) Sistema operativo Windows 10 Home in S mode Dimensiones (Ancho x Profundidad x Altura) 288 x 200 x 17.7-17.9 mm Peso 1.2 kg Color Ice Blue', 200, '299.00', 'Lenovo IdeaPad 1 11IGL05.jpg'),
(8, 'Ordenadores', 'PC Portatil', 'HP 250 G7 Intel Core i5-1035G1', 'Procesador Intel® Core™ i5-1035G1 (4 núcleos, frecuencia desde 1 GHz hasta 3,6 GHz, 6 MB caché) Memoria RAM 8 GB DDR4 2666 MHz (1 x 8 GB); ampliable hasta 16GB (2x SO-DIMM) Disco duro 256 GB SSD NVMe PCIe Almacenamiento óptico DVD±RW Display 15,6\" (39,6 cm) SVA eDP Full HD (1920 x 1080), antirreflectante, con retroiluminación LED, 220 cd/m² Controlador gráfico Integrado: Intel® UHD Conectividad LAN Gigabit (10/100/1000) WiFi 802.11b/g/n (1x1) Bluetooth 4.2 Cámara de portátil Sí, HD Micrófono Sí Batería 3 celdas Ion de litio 41Wh Conexiones 1 x HDMI 1.4b 1 x Combo audio auriculares/micrófono 2 x USB 3.1 1 x USB 2.0 1 x RJ45 Lector de Tarjetas 3 en 1 (SD, SDHC, SDXC) Sistema operativo FreeDOS (SIN SISTEMA OPERATIVO) Dimensiones (Ancho x Profundidad x Altura) 376 x 246 x 22,5 mm Peso 1,78 kg Color Gris oscuro', 200, '605.83', 'HP 250 G7 Intel Core i5-1035G1.jpg'),
(9, 'Ordenadores', 'PC Portatil', 'Asus ZenBook 14 Ultralight UX435EAL-KC096T', 'Procesador Intel Core i7-1165G7 (12MB Cache, 2.8GHz) Memoria RAM 16GB LPDDR4x-SDRAM Almacenamiento 512GB SSD, 32GB Intel Optane Memory Unidad óptica No incluida Display 35.6 cm (14\") Full HD 1920 x 1080 IPS Touch Controlador gráfico Intel Iris Xe Graphics Conectividad Wi-Fi 6 (Gig+)(802.11ax) 2x2 Bluetooth® 5.0 Webcam HD camera with IR function to support Windows Hello Conexiones 1x USB 3.2 Gen 1 Type-A 2x Thunderbolt™ 4 supports display / power delivery 1 x HDMI 2.0b 1 x Lector de Tarjetas Micro SD 1x 3.5mm Combo Audio Jack Sistema operativo SIN SISTEMA OPERATIVO Batería 63WHrs, 3S1P, 3-cell Li-ion Dimensiones (Ancho x Profundidad x Altura) 31.93 x 20.17 x 1.49 ~ 1.56 cm Peso 0.98 kg Color Aluminio, Gris pino', 200, '1350.26', 'Asus ZenBook 14 Ultralight UX435EAL-KC096T.jpg'),
(10, 'Ordenadores', 'Portatil Gaming', 'Asus TUF Gaming FX505DT-HN540', 'Procesador AMD® Ryzen™ 7 3750H APU (4 Núcleos, 8 Subprocesos, Caché: 6MB Level 2&3, 2.3GHz hasta 4.0GHz, 64-bit) Memoria RAM 16GB (8GBx2) DDR4 2400 MHz Disco duro 512GB SSD M.2 PCIe® NVMe Almacenamiento óptico NO TIENE Display 15.6\" (39,62cm) LED Retroiluminado FHD (1920x1080/16:9) 144Hz Controlador gráfico NVIDIA® GeForce® GTX 1650 4GB GDDR5 Conectividad LAN 10/100/1000 Wi-Fi 5 (802.11ac) 1x1 Bluetooth V5.0 High Speed Cámara de portátil Sí Micrófono Sí Batería 48Wh, 3 Celdas, Ion de Litio Conexiones 1 x USB 2.0 2 x USB 3.2 1 x RJ-45 1 x HDMI 2.0 1 x Jack 3.5 Sistema operativo NO TIENE Dimensiones 360 x 262 x 25~26 mm Peso 2,2 kg Color Negro', 200, '768.59', 'Asus TUF Gaming FX505DT-HN540.jpg'),
(11, 'Ordenadores', 'Portatil Gaming', 'MSI Alpha 15 A4DEK-006XES', 'Procesador AMD® Ryzen Ryzen 7 4800H Memoria DDR IV 8GB*2 (3200MHz) Almacenamiento 512GB NVMe PCIe Gen3x4 SSD (new) Unidad óptica No Display 15.6\" FHD (1920*1080), IPS-Level 144Hz 45%NTSC Thin Bezel Controlador gráfico RX5600M, GDDR6 6GB Conectividad Intel Wi-Fi 6 AX200(2*2 ax)+BT5.1 Cámara de portátil HD type (30fps@720p) Micrófono Sí Batería 6 cell , 65Whr Conexiones 1x RJ45 1x SD (XC/HC) Card Reader 1x (4K @ 60Hz) HDMI 1x Mini-DisplayPort 1x Type-C USB3.2 Gen1 3x Type-A USB3.2 Gen1 Teclado retroiluminado Sí, RGB tecla a tecla Sistema operativo SIN SISTEMA OPERATIVO Dimensiones 357.7 x 248 x 26.9 mm Peso 2.4 Kg Color Negro', 200, '942.24', 'MSI Alpha 15 A4DEK-006XES.jpg'),
(12, 'Ordenadores', 'Portatil Gaming', 'MSI GL65 Leopard 10SEK-241XES', 'Procesador Comet lake i7-10750H+HM470) Memoria DDR4 16GB*2 (2666 MHz) Almacenamiento 1TB NVMe PCIe SSD Pantalla 15.6\" FHD (1920*1080), IPS-Level 144Hz 72%NTSC Thin Bezel, close to 100%sRGB Controlador gráfico GeForce® RTX 2060, GDDR6 6GB Conectividad Killer Gb LAN Intel Wi-Fi 6 AX201(2*2 ax) + BT5 Cámara de portátil HD type (30fps@720p) Micrófono Sí Batería 6 celdas de Ion de litio 51 Whr Conexiones 1x USB 3.2 Gen2 Type-C 3x USB 3.2 Gen1 Type-A 1x Mini DisplayPort 1.2 1x HDMI (4K@30Hz) 1x RJ45 1x Lector de tarjetas SD (XC/HC) Sistema operativo Sin sistema operativo Dimensiones 357.7 (W) x 248 (D) x 27.5 (H) mm Peso 2.3 Kg Color Negro', 200, '1249.99', 'MSI GL65 Leopard 10SEK-241XES.jpg'),
(13, 'Impresoras', 'Impresora Laser', 'HP Officejet Pro 6230', 'Velocidad de impresión en negro: ISO: Hasta 18 ppm Borrador: Hasta 29 ppm 1 Velocidad de impresión a color: ISO:Hasta 10 ppm Borrador:Hasta 24 ppm 1 Salida de la primera página (lista) Negro: 14 segundos Color: Velocidad máxima de 17 segundos Ciclo de trabajo (mensual, A4) Hasta 15.000 páginas Volumen de páginas mensual recomendado 200 a 800 (impresión) 3 Tecnología de impresión Inyección térmica de tinta HP Controladores de impresora incluidos HP PCL 3 GUI, HP PCL 3 mejorado Calidad de impresión en negro (óptima) Hasta 600 x 1200 dpi Calidad de impresión en color (óptima) Hasta 600 x 1200 dpi Monitor Panel de control de LED y botones Velocidad del procesador 500 MHz Número de cartuchos de impresión 4 (1 de cada color: negro, cian, magenta y amarillo) Cartuchos de repuesto C2P19AL - Cartucho de tinta original HP 934 negro (~400 páginas) C2P23AL - Cartucho de tinta original HP 934XL de alta capacidad negro (~1000 páginas) C2P24AL - Cartucho de tinta original HP 935XL de alta capacidad cian (~825 páginas) C2P25AL - Cartucho de tinta original HP 935XL de alta capacidad magenta (~825 páginas) C2P26AL - Cartucho de tinta original HP 935XL de alta capacidad amarillo (~825 páginas) Lenguajes de impresión HP PCL 3 GUI, HP PCL 3 mejorado Conectividad Capacidad HP ePrint Capacidad de impresión móvil HP ePrint, Apple AirPrint?, certificación Mopria, impresión directa inalámbrica 2 Capacidad inalámbrica WiFi 802.11b/g/n integrada Conectividad, estándar 1 x USB 2.0 1 x Ethernet 1 x conexión inalámbrica 802.11b/g/n Requisitos mínimos de sistema Windows 7, 8, 8.1: Procesador de 1 GHz y 32 bits (x86) o 64 bits (x64), 2 GB en disco duro, Internet Explorer, CD-ROM/DVD o Internet, USB Windows Vista: Procesador de 800 MHz y 32 bits (x86) o 64 bits (x64), 2 GB en disco duro, Internet Explorer, CD-ROM/DVD o Internet, USB Windows XP SP3 (sólo 32 bits): Procesador Intel Pentium® II, Celeron® o compatible de 233 MHz, 750 MB en disco duro, Internet Explorer 6, CD-ROM/DVD o Internet, USB Mac OS X Lion, OS X Mountain Lion, OS X Mavericks: 1 GB en el disco duro, Internet, USB Sistemas operativos compatibles Windows 8.1 (32 bits y 64 bits), Windows 8 (32 bits y 64 bits), Windows 7 (32 bits y 64 bits), Windows Vista (32 bits y 64 bits), Windows XP (32 bits) (ediciones Professional y Home) Mac OS X v 10.6, v 10.7, v 10.8 ó v 10.9 Linux (para obtener más información, consulte http://hplipopensource.com/hplip-web/index.html). (Sin soporte: Windows 2000 (SP4), Windows XP Professional x64 (SP1)) Especificaciones de memoria Memoria, estándar 256 MB Memoria, máxima Flash SPI de 128 MB, 2 KB EEPROM, 128 MB de DDR3 Uso del papel Entrada de manejo de papel, estándar Bandeja entrada 225 hojas Salida de manejo de papel, estándar Bandeja salida de 60 hojas Impresión a doble cara Automática (estándar) Capacidad de entrada de sobre Hasta 15 sobres Impresión sin bordes Sí, hasta 8,5 x 11 pulgadas (carta Estados Unidos), 210 x 297 mm (A4) Tamaños de soportes de impresión admitidos A4, A5, A6, B5(JIS), 6 x 8 pulgadas, Ejecutivo, Tarjeta índice 3,5 x 5 pulgadas, Tarjeta índice 4 x 6 pulgadas, Tarjeta índice 5 x 8 pulgadas, Tarjeta índice A4, Tarjeta índice carta, 3 x 5 pulgadas, 4 x 6 pulgadas, 5 x 7 pulgadas, 13 x 18 cm, 8 x 10 pulgadas, 10 x 15 cm, L, Foto 2L, 8,5 x 13 pulgadas, Legal, Carta, Declaración, Ofuku Hagaki, Postal japonés, Sobre #10, Sobre A2, Sobre C5, Sobre C6, Sobre DL Sobre Monarca, Sobre tarjeta 4,4 x 6 pulgadas, JIS Chou #3, JIS Chou #4 Tamaños de soportes, personalizado de 3 x 5 pulgadas 8,5 x 14 pulgadas (simple), de 3 x 5,5 pulgadas a 8,5 x 12,2 pulgadas (doble cara automático) Tipos de soportes Papel común, papeles fotográficos HP, Papel profesional o folleto mate HP, papel presentación mate HP, papel profesional o folleto con brillo, Otros papeles fotográficos para chorro de tinta, otros papeles mate para chorro de tinta, otros papeles con brillo para chorro de tinta, Hagaki para chorro de tinta, papel común grueso Gramajes de soportes, recomendados 16 a 28 lb (papel normal) 60 a 75 lb (fotográfico) 20 a 24 lb (sobre) 90 a 110 lb (tarjeta) Peso de soporte, admitido Papel común: 16 a 28 lb. bond Requisitos de operación y alimentación Alimentación Tensión de entrada: de 100 a 240 VCA (+/- 10%), 50/60 Hz (+/- 3 Hz) Consumo de energía 24 watts máximo, 3,3 watts (activa), 0,5 watts (apagado manual), 1,16 watts (suspensión) 4 Eficiencia de energía Apto para ENERGY STAR® Margen de temperaturas operativas 5 a 40ºC Intervalo de humedad en funcionamiento del 20 al 80% de HR sin condensación Dimensiones y peso Dimensiones mínimas (ancho x profundidad x altura) 464 x 385 x 145,5 mm Peso 5,1 kg Peso del embalaje 7 kg Qué se incluye ePrinter HP Officejet Pro 6230 Cable de alimentación Cartuchos de tinta host Guía del usuario Póster de configuración', 500, '74.00', 'HP Officejet Pro 6230.jpg'),
(14, 'Impresoras', 'Impresora Laser', 'Brother HL1210W', 'Memoria Memoria interna: 32 MB Puertos e Interfaces Interfaz estándar: USB 1.1, USB 2.0, LAN inalámbrica Cantidad de puertos USB 2.0: 1 Peso y dimensiones Ancho: 340 mm Profundidad: 238 mm Altura: 189 mm Peso: 4,6 kg Ancho del paquete: 415 mm Profundidad del paquete: 303 mm Altura del paquete: 324 mm Peso del paquete: 5,5 kg Velocidad de la impresión Velocidad de impresión (negro, calidad normal, A4/US Carta): 20 ppm Tiempo de calentamiento: 18 s Tiempo hasta primera página (negro, normal): 10 s Modos de impresión a doble cara: Manual Impresión n por cara: 2, 4, 6, 9, 16, 25 Capacidad de salida Capacidad de salida estándar: 50 hojas Capacidad de la entrada Capacidad de entrada estándar: 150 hojas Tecnología de la impresión Color: No Resolución máxima: 2400 x 600 DPI Ciclo de trabajo (máximo): 10000 páginas por mes Impresión dúplex: No Número de cartuchos de impresión: 1 Lenguaje: GDI Tecnología de impresión: Laser Colores de impresión: Negro Ciclo de trabajo: 250 - 1800 páginas por mes Control de energía Voltaje de entrada: 220-240 Frecuencia de entrada: 50/60 Consumo energético: 380 W Consumo de energía (max): 1056 W Consumo de energía (inactivo): 40 W Consumo de energía (ahorro): 0,7 W Consumo de energía (apagado): 0,28 W Condiciones ambientales Intervalo de temperatura operativa: 10 - 32 °C Intervalo de temperatura de almacenaje: 0 - 40 °C Intervalo de humedad relativa para funcionamiento: 20 - 80% Intervalo de humedad relativa durante almacenaje: 35 - 85% Red Ethernet: No Wifi: Si Listo para redes: Si Wi-Fi estándares: 802.11b, 802.11g, 802.11n Algoritmos de seguridad soportados: 128-bit WEP, 64-bit WEP, SMTP-AUTH, WPA-AES, WPA-PSK, WPA-TKIP, WPA2-AES, WPA2-PSK, WPS Protocolos de network soportados (IPv4): ARP, RARP, BOOTP, DHCP, APIPA(Auto IP), WINS/NetBIOS, DNS resolver, mDNS, LLMNR responder, LPR/LPD, Custom Raw Port/Port 9100, IPP, FTP Server, SNMPv1/v2c, HTTP Server, TFTP Client/Server, SMTP Client, ICMP, Web Services Protocolos de network soportado (IPv6): NDP, RA, DNS Resolver, mDNS, LLMNR responder, LPR/LPD, Custom Raw Port/ Port 9100, IPP, FTP Server, SNMPv1/v2c, HTTP Server, TFTP Client/Server, SMTP Client, ICMPv6, Web Services Tecnología de impresión móvil: Brother iPrint & Scan Emisión de sonidos Nivel de ruido de impresión: 51 dB Dirección de papel Tamaño máximo de papel ISO A-series: A4 Tipos de bandeja estándar: Papel normal, Papel reciclado ISO tamaño de serie A (A0...A9): A4, A5 ISO tamaño de serie B (B0...B9): B5 Tamaño de impresora No-ISO: Executive, Folio, A4, Carta Peso de papel en bandeja estándar: 65 - 105 g/m² Formato a medida, ancho: 148 - 216 mm Formato a medida, largo: 148 - 355,6 mm Aprobaciones reguladoras Certificado Energy Star: Si Certificado para Blue Angel: Si Diseño Color del producto: Negro, Color blanco Pantalla incorporada: Si Pantalla: LED LED de energía: Si LED de suspendido: Si Desempeño Procesador incorporado: Si Familia de procesador: ARM Cortex Modelo del procesador: ARM9 Frecuencia del procesador: 200 MHz Sistema operativo Windows soportado: Windows 7 Home Basic, Windows 7 Home Basic x64, Windows 7 Home Premium, Windows 7 Home Premium x64, Windows 7 Professional, Windows 7 Professional x64, Windows 7 Starter, Windows 7 Starter x64, Windows 7 Ultimate, Windows 7 Ultimate x64, Windows 8, Windows 8 Enterprise, Windows 8 Enterprise x64, Windows 8 Pro, Windows 8 Pro x64, Windows 8 x64, Windows 8.1, Windows 8.1 Enterprise, Windows 8.1 Enterprise x64, Windows 8.1 Pro, Windows 8.1 Pro x64, Windows 8.1 x64, Windows Vista Business, Windows Vista Business x64, Windows Vista Enterprise, Windows Vista Enterprise x64, Windows Vista Home Basic, Windows Vista Home Basic x64, Windows Vista Home Premium, Windows Vista Home Premium x64, Windows Vista Ultimate, Windows Vista Ultimate x64, Windows XP Home, Windows XP Home x64, Windows XP Professional x64 Sistema operativo MAC soportado: Mac OS X 10.7 Lion, Mac OS X 10.8 Mountain Lion, Mac OS X 10.9 Mavericks Sistema operativo Linux soportado: Si Sistema operativo de servidor soportado: Windows Server 2003, Windows Server 2003 x64, Windows Server 2008, Windows Server 2008 R2, Windows Server 2008 x64, Windows Server 2012 R2 x64, Windows Server 2012 x64 Otros sistemas operativos soportados: Windows Phone, Android, iOS', 500, '123.28', 'Brother HL1210W.jpg'),
(15, 'Impresoras', 'Impresora Laser', 'HP LaserJet Pro M15w', 'Memoria Memoria interna: 8 MB Memoria interna máxima: 8 MB Requisitos del sistema Espacio mínimo del disco duro: 2048 MB Puertos e Interfaces Interfaz estándar: USB, LAN inalámbrica Peso y dimensiones Ancho: 346 mm Profundidad: 189 mm Altura: 159 mm Peso: 3,8 kg Ancho del paquete: 378 mm Profundidad del paquete: 198 mm Altura del paquete: 222 mm Peso del paquete: 4,8 kg Velocidad de la impresión Velocidad de impresión (negro, calidad normal, A4/US Carta): 18 ppm Tiempo hasta primera página (negro, normal): 8,4 s Capacidad de salida Capacidad de salida estándar: 100 hojas Capacidad de salida máxima: 100 hojas Capacidad de la entrada Capacidad de entrada estándar: 150 hojas Capacidad de entrada máxima: 150 hojas Cantidad de bandejas de papel estándar: 1 Número máximo de bandejas de papel: 1 Tipo de papel de entrada: Impresión de láminas Tecnología de la impresión Color: No Resolución máxima: 600 x 600 DPI Ciclo de trabajo (máximo): 8000 páginas por mes Número de cartuchos de impresión: 1 Lenguaje: PCLmS,PWG,URF Tecnología de impresión: Laser Colores de impresión: Negro Ciclo de trabajo: 100 - 1000 páginas por mes Control de energía Voltaje de entrada: 220-240 Frecuencia de entrada: 50/60 Consumo de energía (max): 210 W Consumo de energía (ahorro): 0,4 W Consumo de energía (preparado): 2,2 W Consumo de energía (apagado): 0,1 W Enery Star Consumo Electrico Típico (TEC): 0.424 Condiciones ambientales Intervalo de temperatura operativa: 15 - 32,5 °C Intervalo de humedad relativa para funcionamiento: 30 - 70% Conexión Ethernet: No Wifi: Si Tecnología de impresión móvil: Apple AirPrint,Google Cloud Print,Mopria Print Service Wi-Fi estándares: IEEE 802.11b,IEEE 802.11g,IEEE 802.11n Dirección de papel Tamaño máximo de papel ISO A-series: A4 Tipos de bandeja estándar: Sobres, Etiquetas, Papel normal, Postcard Tamaño de sobres: C6,DL Formato a medida, ancho: 105 - 216 mm Formato a medida, largo: 148 - 297 mm Tamaño máximo de impresión: 216 x 279 mm Peso de papel en bandeja estándar: 29,5 - 54,4 kg (65 - 120 libras) Aprobaciones reguladoras Certificado Energy Star: Si Conformidad EPEAT: Plata Contenido del embalaje Cartucho (s) incluido: Si Controladores incluidos: Si Cable de alimentación incluido: Si Manual de usuario: Si CD de software: Si CD de documentación: Si Incluye cable USB: Si Características especiales ePrint HP: Si Diseño Color del producto: Blanco Pantalla incorporada: Si Pantalla: LED Pantalla a color: No Desempeño Procesador incorporado: Si Frecuencia del procesador: 500 MHz Sistema operativo Windows soportado: Windows 10,Windows 7,Windows 8,Windows 8.1 Sistema operativo MAC soportado: Mac OS X 10.11 El Capitan,Mac OS X 10.12 Sierra,Mac OS X 10.13 High Sierra', 200, '115.40', 'HP LaserJet Pro M15w.jpg'),
(16, 'Impresoras', 'Impresora 3D', 'Anet A8', 'Marco: Marco de acrílico Tamaño de impresión: 220 * 220 * 240 mm Velocidad de impresión: 40-120 mm / s Diámetro de filamento: 1.75 mm Soporte de filamento: ABS, PLA, madera, flexible, etc. Precisión: eje Z: 0.004 mm; Eje XY: 0.012 mm Precisión de impresión: ± 0.1-0.2 mm Grosor del espesor: 0.1-0.3mm LCD Pantalla: 2004 Diámetro de la boquilla: 0.2 / 0.3 / 0.4 / 0.5 / 0.6mm Potencia: 110 / 220V, 250W Temperatura de control: Extrusora: Max 260 ° C; Cama caliente: Max100 ° Formato de impresión de CP: .STL / .OBJ / .JPG / G-code OS: Windows / Linux / Mac Interfaz de operación: inglés Conectores: Tarjeta TF / Online Auto Nivelador: opcional Tamaño de impresora: 500 * 400 * 450 mm; Peso neto: 8.5 Tamaño del paquete KG: 510 * 310 * 208 mm; Peso bruto: 9.0 kg', 200, '199.00', 'Anet A8.jpg'),
(17, 'Impresoras', 'Impresora 3D', 'Creality CR-6 SE', 'Propiedades de la impresora 3D CR-6 SE FDM Tecnología de modelado: FDM ?Modelado por deposición fundida? Tamaño de impresión: 235x235x250mm Formatos de archivo: STL / OBJ / AMF Software de corte: Creality Slicer / Cura / Reptier-Host / Simplify3D Velocidad de impresión: 80-100 mm / s Reanudar la función de impresión: Sí Materiales compatibles: PLA / TPU / PETG / ABS / WOOD Transferencia de archivos: tarjeta USD / SD Hardware de la impresora 3D CR-6 SE FDM Peso de la máquina: 9,5 kg Placa base: placa base silenciosa Voltaje nominal: 100v-240v AC 50 / 60HZ Potencia nominal: 350 W Voltaje de salida: DC24V Funcionamiento: pantalla táctil a color de 4,3 pulgadas Sensor de filamento: sensor fotoeléctrico Tamaño de la máquina: 442x462x540 mm Eje Z: eje Z doble Idiomas: chino / inglés Sin nivelación: sí Hardware del extrusor de impresora 3D CR-6 SE FDM Espesor de la capa: 0,1-0,4 mm Precisión de posición XY: 0,01 mm Resolución de impresión: ± 0,1 mm Temperatura de la boquilla: ?260 ? Diámetro de la boquilla: 0,4 mm (se admiten más opciones) Temperatura del semillero: ?110 ?', 198, '399.95', 'Creality CR-6 SE.jpg'),
(18, 'Impresoras', 'Impresora 3D', 'Bresser Rex II', 'Impresión continua aunque se vaya la luz Máximo tamaño de impresión: 280 x 250 x 300 mm Filamento: Bobina ABS/PLA/PVA 1,75mm Precisión de impresión: ±0,10 mm Aviso cuando el filamento está próximo a acabarse Precisión de posicionamiento: XY: 11 µm [0,0004 pulgadas] Z: 2.5 µm [0,0001 pulgadas] Pantalla táctil Espesor de la capa: 0,05 ~ 0,4 mm Función de vista previa de impresión (formato gx) Diámetro de la boquilla: 0,40 mm Máxima temperatura del extrusor: 240 ºC Diseño compacto con sistema de control de temperatura Conexión: Cable USB Pendrive Internet Sistema operativo: Windows XP / Vista / 7 / 8 / 10 Mac OS Linux Potencia: TBD 450W Certificado: CE, FCC, ROHS Software: Flashprint Temperatura de la cama: ABS: 110 - 115 ºC PLA: 50 ºC Tipo de archivo: Entrada: 3MF/STL/ OBJ/FPP/BMP/PNG/JPG/JPEG Salida: gx/g Idioma: Alemán, chino, coreano, francés, inglés, lituano, japonés y checo Velocidad: 30-200 mm/s Flujo de la boquilla: 24 cc/h Peso del paquete: 35 kg', 200, '1349.00', 'Bresser Rex II.jpg'),
(19, 'Smart TV', 'Smart TV FULL HD', 'Philips 24PFS6805', 'Exhibición Diagonal de la pantalla: 61 cm (24\") Tipo HD: Full HD Tecnología de visualización: LED Forma de la pantalla: Plana Relación de aspecto nativa: 16:9 Formato de pantalla, ajustes: Acercar Resolución de la pantalla: 1920 x 1080 Pixeles Diagonal de pantalla: 60 cm Sintonizador de la TV Tipo de sintonizador: Analógico y digital Señal analógica: PAL,SECAM Formato de señal digital: DVB-C,DVB-S,DVB-S2,DVB-T,DVB-T2,DVB-T2 HD Smart TV Smart TV: Si TV por Internet: Si Vídeo a la carta de apoyo (VOD): Si HbbTV: Si Aplicaciones de vídeo: NetFlix,YouTube Audio Número de altavoces: 2 Potencia estimada RMS: 6 W Ecualizador: Si Cantidad de bandas en ecualizador: 5 Conexión Wifi: Si Ethernet: Si Wi-Fi estándares: Wi-Fi 4 (802.11n) Diseño montaje VESA: Si Interfaz de panel de montaje: 75 x 75 mm Pantalla flexible: No Color del producto: Negro Indicación de la fuerza de la señal: Si Libre de metales pesados: Hg (mercurio) Desempeño Alto Rango Dinámico (HDR): Si Tecnología HDR (High Dynamic Range, Alto rango dinámico): High Dynamic Range 10 (HDR10),Hybrid Log-Gamma (HLG) Funciones de teletexto: Si Teletexto: 1000 páginas Estándares de teletexto: Hipertexto Formatos de vídeo compatibles: AVC,AVI,H.264,HEVC,MKV,MPEG1,MPEG2,MPEG4,VC-1,VP9,WMV9 Formatos de audio soportados: AAC,MP3,WAV,WMA,WMA-PRO Formatos de imagen soportados: BMP,GIF,HEIF,JPEG,PNG Formatos de subtítulos soportados: ASS,SMI,SRT,SSA,SUB,TXT Grabación USB: Si Puertos e Interfaces Canal de retorno de audio (ARC): Si Puerto DVI: No Ethernet LAN (RJ-45) cantidad de puertos: 1 Cantidad de puertos USB 2.0: 2 Audio digital, salida optica: 1 Salidas para auriculares: 1 Número de puertos RF: 2 Tipo de conector RF: F, IEC Interfaz común: Si Interfaz común Plus (CI+): Si Número de puertos HDMI: 3 PC (D-Sub): Si Control de electrónica de consumo (CEC): EasyLink Características de administración Guía electrónica de programación: Si Periodo de programación: 8 día(s) Imagen muda (para radio): Si Modo ECO: Si Temporizador Encendido/Apagado: Si Firmware actualizable: Si Firmware actualizable mediante: Asistente para actualización automática, Red, USB Control de energía Clase de eficiencia de energía: A Consumo de energía anual: 37 kWh Consumo energético: 25 W Consumo de energía (inactivo): 0,3 W Voltaje de entrada AC: 220 - 240 V Frecuencia de entrada AC: 50/60 Hz Condiciones ambientales Intervalo de temperatura operativa: 5 - 35 °C Peso y dimensiones Ancho: 567,4 mm Profundidad: 73,7 mm Altura: 340,4 mm Ancho del dispositivo (con soporte): 567,4 mm Profundidad dispositivo (con soporte): 135 mm Peso: 2,9 kg Altura del dispositivo (con soporte): 363,2 mm Peso con stand: 2,9 kg Empaquetado Soporte de sobremesa: Si Cables incluidos: Corriente alterna Mando a distancia: Si Ancho del paquete: 630 mm Profundidad del paquete: 120 mm Altura del paquete: 425 mm Peso del paquete: 3,9 kg Tipo de embalaje: Caja', 500, '170.44', 'Philips 24PFS6805.jpg'),
(20, 'Smart TV', 'Smart TV FULL HD', 'Samsung UE32T5305', 'Exhibición Diagonal de la pantalla: 81,3 cm (32\") Tipo HD: Full HD Tecnología de visualización: LED Forma de la pantalla: Plana Formato de vídeo soportado: 1080p Formatos gráficos soportados: 1920 x 1080 (HD 1080) Tecnología de interpolación de movimiento: PQI (Picture Quality Index) 1000 Nombre comercial de la relación de contraste dinámico: Mega Contrast Resolución de la pantalla: 1920 x 1080 Pixeles Diagonal de pantalla: 80 cm Sintonizador de la TV Tipo de sintonizador: Analógico y digital Formato de señal digital: DVB-C,DVB-T Autobusqueda de canal: Si Smart TV Smart TV: Si Sistema operativo instalado: Tizen HbbTV: Si Modos inteligentes: Película, Natural Audio Potencia estimada RMS: 10 W Subwoofer incorporado: No Decodificadores incorporados: Dolby Digital Tecnologías de decodificación de audio: Dolby Digital Plus Conexión Wifi: Si Ethernet: Si Wi-Fi Direct: Si Navegador web: Si Diseño montaje VESA: Si Color del producto: Negro Desempeño Alto Rango Dinámico (HDR): Si Modo de juego: Si Funciones de teletexto: Si Función de subtítulos: Si Oscurecimiento local: Si Tecnología de procesamiento de imagen: Samsung Contrast Enhancer,Samsung HyperReal Engine Digital Clean View: Si ConnectShare (HDD): Si ConnectShare (USB): Si Puertos e Interfaces Cambio rápido entre entradas HDMI: Si Canal de retorno de audio (ARC): Si Ethernet LAN (RJ-45) cantidad de puertos: 1 Cantidad de puertos USB 2.0: 1 Video componente (YPbPr/YCbCr) entrada: 1 Entrada de video compuesto: 1 Audio digital, salida optica: 1 Número de puertos RF: 2 Interfaz común: Si Interfaz común Plus (CI+): Si Versión Common interface Plus (CI+): 1.4 Número de puertos HDMI: 2 Control de electrónica de consumo (CEC): Anynet+ Características de administración Guía electrónica de programación: Si Exhibición en pantalla (OSD): Si Número de lenguajes OSD: 27 Apagado automático: Si Control de energía Clase de eficiencia de energía: A+ Consumo de energía anual: 46 kWh Consumo energético: 33 W Consumo de energía (inactivo): 0,5 W Consumo de energía (ahorro): 28,7 W Consumo de energía (max): 75 W Voltaje de entrada AC: 220 - 240 V Frecuencia de entrada AC: 50/60 Hz Modo de ahorro de energía: Si Aprobaciones reguladoras Certificado (DLNA) alianza para el estilo de vida digital en red: Si Peso y dimensiones Ancho: 737,4 mm Profundidad: 74,1 mm Altura: 438 mm Peso: 4 kg Ancho del dispositivo (con soporte): 737,4 mm Profundidad dispositivo (con soporte): 150,5 mm Altura del dispositivo (con soporte): 465,4 mm Peso con stand: 4,1 kg Empaquetado Mando a distancia: Si Tipo de control remoto: TM1240A Pilas incluidas: Si Ancho del paquete: 879 mm Profundidad del paquete: 127 mm Altura del paquete: 500 mm Peso del paquete: 5,5 kg', 496, '249.01', 'Samsung UE32T5305.jpg'),
(21, 'Smart TV', 'Smart TV FULL HD', 'LG 32LM6300PLA', 'Exhibición Diagonal de la pantalla: 81,3 cm (32\") Tipo HD: Full HD 3D: No Resolución de la pantalla: 1920 x 1080 Pixeles Tecnología de visualización: Direct-LED Forma de la pantalla: Plana Relación de aspecto: 16:9 Audio Altavoces incorporados: Si Potencia estimada RMS: 10 W Modos de sonido: Clear Voice III Puertos e Interfaces Número de puertos HDMI: 3 Ethernet LAN (RJ-45) cantidad de puertos: 1 Cantidad de puertos USB 2.0: 2 Interfaz común: Si Interfaz común Plus (CI+): Si Versión HDMI: 1.4 Canal de retorno de audio (ARC): Si Audio digital, salida optica: 1 Número de puertos RF: 2 Tipo de conector RF: F, IEC Versión Common interface Plus (CI+): 1.4 Control de electrónica de consumo (CEC): SimpLink Peso y dimensiones Ancho: 736 mm Profundidad: 82,9 mm Altura: 437 mm Peso: 4,65 kg Ancho del dispositivo (con soporte): 736 mm Profundidad dispositivo (con soporte): 180 mm Altura del dispositivo (con soporte): 464 mm Peso con stand: 4,7 kg Control de energía Clase de eficiencia de energía: A Consumo de energía anual: 50 kWh Consumo energético: 36 W Consumo de energía (inactivo): 0,5 W Voltaje de entrada AC: 100 - 240 V Frecuencia de entrada AC: 50/60 Hz Conexión Wifi: Si Ethernet: Si Wi-Fi estándares: 802.11a,802.11b,802.11g,Wi-Fi 4 (802.11n),Wi-Fi 5 (802.11ac) Bluetooth: Si Versión de Bluetooth: 5.0 Sintonizador de la TV Tipo de sintonizador: Digital Formato de señal digital: DVB-C,DVB-S2,DVB-T2 Aprobaciones reguladoras Certificado (DLNA) alianza para el estilo de vida digital en red: Si Características de administración Guía electrónica de programación: Si Periodo de programación: 8 día(s) Contenido del embalaje Mando a distancia: Si Diseño Color del producto: Negro montaje VESA: Si Interfaz de panel de montaje: 200 x 200 mm Desempeño Funciones de teletexto: Si Imágenes de alto rango dinámico (HDRI): Si Teletexto: 2000 páginas Formatos de audio soportados: AAC,AC3,DTS,EAC3,HE-AAC,MP2,MP3,PCM,WMA,apt-X Reducción de ruido: Si Número de núcleos de procesador: 4 Smart TV Smart TV: Si TV por Internet: Si Sistema operativo instalado: Web OS Grabación diferida (timeshift): Si', 498, '288.94', 'LG 32LM6300PLA.jpg'),
(22, 'Smart TV', 'Smart TV 4K', 'Samsung UE43AU7105KXXC', 'Pantalla Tamaño de pantalla 108 cm (43”) Resolución 3,840 x 2,160 Vídeo Motor de Imagen Procesador Crystal UHD PQI 2000 HDR HDR HDR 10+ Soporte HLG (Hybrid Log Gamma) Sí Contraste Mega Contrast Color Pur Color Ángulo de visualización N/A Micro Dimming UHD Dimming Contrast Enhancer Sí Modo cine Sí Modo natural Sí Audio Dolby Digital Plus Sí Q-Symphony Q-Symphony Audio Pre-selection Descriptor Sí Salida de sonido (RMS) 20W Tipo de altavoz 2CH Servicios Smart Smart TV Smart Operating System Tizen™ Works with Google Assistant Sí Works With Alexa Sí TV Plus Sí Navegador web Sí SmartThings App Support Sí Universal Guide Sí Gallery Sí Convergencia Mirroring (DLNA) de Móvil a Televisor Sí Mobile Tap Mirroring Sí Remote Access Básico Wi-Fi Direct Sí Sonido de TV en smartphone Sí Sound Mirroring Sí Sintonizador Sintonizador digital DVB-T2C Sintonizador analógico Sí CI (Interfaz común) CI+(1.4) HbbTV HbbTV 2.0.2 TV Key Support Sí Conectividad HDMI 3 USB 1 Entrada de red (LAN) Sí Salida de Audio Digital (Óptica) 1 Entrada RF (Terrestre/Entrada cable/Entrada Satélite) 1/1 (uso común para señal terrestre) / 0 CI Slot 1 HDMI A / Retorno al Canal Sí eARC Sí Conexión rápida HDMI Sí Wi-Fi Integrado Sí (WiFi5) Bluetooth Sí (BT4.2) Anynet+ (HDMI-CEC) Sí Diseño Diseño Sin Marco Tipo de marco 3 Bezel-less Slim Slim look Color Frontal TITAN GRAY Tipo de peana SLIM FEET Stand Color TITAN GRAY Características Adicionales Adaptive Sound Adaptive Sound Brightness/Color Detection Detector Brillo/Color Accessibility - Learn TV Remote / Learn Menu Screen Inglés (Reino Unido), alemán, francés, español, italiano, holandés, polaco, danés, sueco, finlandés, noruego, portugués, ruso (solo cuando se conecta a la red en EE, LV, LT) Accessibility - Others Ampliar / Contraste alto / Audio de salida múltiple / Inversión de color / Escala de grises / Zoom en lenguaje de señas / Repetición Digital Clean View Sí Búsqueda Automática de Canales Sí Auto Apagado Sí Subtítulos Sí ConnectShare™ (HDD) Sí ConnectShare™ (USB 2.0) Sí EPG Sí Filmmaker Mode (FMM) Sí Idiomas Sistema Operativo 27 Idiomas europeos + Ruso(solo cuando se conecta a la red en EE, LV, LT) BT HID integrado Sí Soporte USB HID Sí Teletexto Sí Compatible con IPv6 Sí Compatible con mando universal Sí Características Eco Sensor Eco Sí Clase de Eficiencia Energética G Intensidad Máxima Fuente de Alimentación AC220-240V 50/60Hz Consumo de Energía (Máx.) 125 W Consumo (Stand-by) 0,50 W Consumo (Modo Ahorro de Energía) (W) N/A Power Consumption (Typical) 70,0 W Dimensiones Dimensión con Caja (mm) 1081 x 670 x 143 mm Dimensión con Peana (mm) 963.9 x 627.8 x 192.5 mm Dimensión sin Peana (mm) 963.9 x 558.9 x 59.6 mm Tamaño de la peana (AnxProf) 841.7 x 192.5 mm Stand (Minimum) (WxD) N/A Peso Peso con Caja (kg) 11,8 kg Peso con Peana (kg) 8,3 kg Peso sin Peana (kg) 8,1 kg Accesorios Modelo de Mando a Distancia TM2140A (UK: TM2140A/TM1240A) Baterias (para el Mando) Sí Optional Stand Support (Y20 Studio) Sí Compatible con Soporte Mini Sí Compatible con Soporte VESA Sí Manual de Usuario Sí e-Manual Sí Cable Alimentación Sí', 496, '408.18', 'Samsung UE43AU7105KXXC.jpg'),
(23, 'Smart TV', 'Smart TV 4K', 'Xiaomi Mi TV 4S', 'Display 43 pulgadas 4K UHD Dimensión diagonal: 108 cm Resolución: 3840 x 2160 Frecuencia de actualización: 60Hz Ángulo de visión: 178º (H) / 178º (V) Brillo: 250 nits Procesadores y sistema operativo CPU: Quad Core (hasta 1.5 GHz) GPU: Mali 470 MP3 hasta 650MHz RAM: 2GB DDR Almacenamiento flash: 8GB eMMC PatchWall OS, Android TV 9.0 Diseño y dimensiones Incluyendo base: 959.55 x 208.33 x 608.14 mm Peso (sin base): 7.2kg Montaje en pared: 300 x 300 mm Color: Metallic Grey Audio Altavoz: 2 * 8W DTS-HD Dolby Audio Conectividad HDMI x 3 (ARC x 1) USB 2.0 x 3 Bluetooth 4.2, BLE 2.4&5GHz Wi-Fi (802.11 a / b / g / n / ac) Puerto Ethernet x 1 Conector de auriculares de 3,5 mm x 1 Entrada AV DVB-T2, DVB-C, DVB-S2 Cl + Optical x 1 Alimentación Consumo de energía: 85 W Voltaje: 100-240 V-50/60 HZ Contenido del paquete Mi TV 4S 43\" x 1, control remoto x 1, manual del usuario x 1', 500, '390.00', 'Xiaomi Mi TV 4S.jpg'),
(24, 'Smart TV', 'Smart TV 4K', 'LG 55NANO813NA', 'Exhibición Diagonal de la pantalla: 139,7 cm (55\") Tipo HD: 4K Ultra HD Tecnología de visualización: NanoCell Forma de la pantalla: Plana Relación de aspecto nativa: 16:9 Resolución de la pantalla: 3840 x 2160 Pixeles Diagonal de pantalla: 140 cm Sintonizador de la TV Tipo de sintonizador: Digital Formato de señal digital: DVB-S2,DVB-T2 Autobusqueda de canal: Si Smart TV Smart TV: Si TV por Internet: Si Sistema operativo instalado: Web OS Versión de sistema operativo: 5,0 Compatible con Apple AirPlay 2: Si HbbTV: Si Aplicaciones de vídeo: Amazon Prime Video, Apple TV, Guindilla, Disney+, Infinity, Mediaset Play, NetFlix, Now TV, RaiPlay, Rakuten, YouTube, tivùon!, tivùsat 4K Audio Número de altavoces: 2 Potencia estimada RMS: 20 W Modos de sonido: AI Sound,Clear Voice III Conexión Wifi: Si Ethernet: Si Wi-Fi estándares: Wi-Fi 5 (802.11ac) Bluetooth: Si Versión de Bluetooth: 5.0 Diseño montaje VESA: Si Interfaz de panel de montaje: 300 x 300 mm Pantalla flexible: No Color del producto: Negro Desempeño Alto Rango Dinámico (HDR): Si Tecnología HDR (High Dynamic Range, Alto rango dinámico): Dolby Vision IQ,Filmmaker Mode,HDR Effect,High Dynamic Range 10 Pro (HDR10 Pro),Hybrid Log-Gamma Pro (HLG Pro) Funciones de teletexto: Si Teletexto: 2000 páginas Función de subtítulos: Si Formatos de audio soportados: AAC,AAC HE,AC3,AC4,MP2,MP3,PCM,WMA Oscurecimiento local: Si Número de núcleos de procesador: 4 AMD FreeSync: No NVIDIA G-SYNC: No Grabación USB: No Puertos e Interfaces Canal de retorno de audio (ARC): Si Puerto DVI: No Ethernet LAN (RJ-45) cantidad de puertos: 1 Cantidad de puertos USB 2.0: 2 Video componente (YPbPr/YCbCr) entrada: 1 Audio digital, salida optica: 1 Interfaz común: Si Interfaz común Plus (CI+): Si Versión Common interface Plus (CI+): 1.4 Número de puertos HDMI: 4 PC (D-Sub): No Características de administración Guía de voz: Si Exhibición en pantalla (OSD): Si Número de lenguajes OSD: 37 Temporizador de apagado: Si Funciona con Amazon Alexa: Si Funciona con el Asistente de Google: Si Control de energía Clase de eficiencia de energía: A Consumo de energía anual: 136 kWh Consumo energético: 98 W Consumo de energía (inactivo): 0,5 W Voltaje de entrada AC: 100 - 240 V Frecuencia de entrada AC: 50/60 Hz Aprobaciones reguladoras Certificado (DLNA) alianza para el estilo de vida digital en red: Si Certificación: CAMREADY / Lativu 4K Peso y dimensiones Ancho: 1232 mm Profundidad: 63,6 mm Altura: 716 mm Ancho del dispositivo (con soporte): 1232 mm Profundidad dispositivo (con soporte): 263 mm Peso: 17,2 kg Altura del dispositivo (con soporte): 786 mm Peso con stand: 18,7 kg Empaquetado Soporte de sobremesa: Si Mando a distancia: Si Tipo de control remoto: AN-MR20GA Ancho del paquete: 1360 mm Profundidad del paquete: 207 mm Altura del paquete: 810 mm Peso del paquete: 24,1 kg Tipo de embalaje: Caja', 500, '748.56', 'LG 55NANO813NA.jpg');
INSERT INTO `productostienda` (`idproducto`, `tipo`, `subtipo`, `nombre`, `descripcion`, `cantidad`, `precio`, `imagen`) VALUES
(25, 'Smart TV', 'Smart TV 8K', 'LG 55NANO956NA', 'Exhibición Diagonal de la pantalla: 139,7 cm (55\") Tipo HD: 8K Ultra HD Tecnología de visualización: NanoCell Tipo de retroiluminación LED: Conjunto completo Forma de la pantalla: Plana Relación de aspecto nativa: 16:9 Tecnología de interpolación de movimiento: TruMotion 100 Hz Frecuencia nativa de refresco: 50 Hz Número de colores de la pantalla: 1,073 billones de colores Resolución de la pantalla: 7680 x 4320 Pixeles Diagonal de pantalla: 139 cm Pantalla giratoria: No Sintonizador de la TV Tipo de sintonizador: Analógico y digital Formato de señal digital: DVB-S2,DVB-T2 Autobusqueda de canal: Si Smart TV Smart TV: Si TV por Internet: Si Sistema operativo instalado: Web OS Versión de sistema operativo: 5,0 Grabación diferida (timeshift): Si Compatible con Apple AirPlay 2: Si HbbTV: Si Aplicaciones de vídeo: Amazon Prime Video, Apple TV, BBC iPlayer, Guindilla, Disney+, Infinity, Mediaset Play, NetFlix, Now TV, RaiPlay, Rakuten, Twitch, YouTube, tivùon!, tivùsat 4K Audio Número de altavoces: 4 Potencia estimada RMS: 40 W Decodificadores incorporados: Dolby Atmos Modos de sonido: AI Sound Pro Enhanced Audio Return Channel (eARC) (Canal de retorno de audio mejorado): Si Conexión Wifi: Si Ethernet: Si Wi-Fi estándares: Wi-Fi 5 (802.11ac) Bluetooth: Si Versión de Bluetooth: 5.0 Miracast: Si Navegación: Si Navegador web: Si Diseño Interruptor de encendido/apagado integrado: Si montaje VESA: Si Interfaz de panel de montaje: 300 x 300 mm Pantalla flexible: No Color del producto: Aluminio, Negro Iluminación ambiental: No Desempeño Alto Rango Dinámico (HDR): Si Tecnología HDR (High Dynamic Range, Alto rango dinámico): Dolby Vision IQ,Filmmaker Mode,HDR Effect,High Dynamic Range 10 Pro (HDR10 Pro),Hybrid Log-Gamma Pro (HLG Pro) Modo de juego: Si Formatos de vídeo compatibles: HEVC,VP9 Oscurecimiento local: Si Tecnología de procesamiento de imagen: LG AI Picture Pro Reducción de ruido: Si AMD FreeSync: No NVIDIA G-SYNC: No Grabación USB: Si Puertos e Interfaces Versión HDMI: 2.1 Canal de retorno de audio (ARC): Si Enlace de alta definición móvil (MHL): No HDCP: Si Puerto DVI: No Ethernet LAN (RJ-45) cantidad de puertos: 1 Cantidad de puertos USB 2.0: 3 Audio digital, salida optica: 1 Salidas para auriculares: 1 Número de puertos RF: 2 Interfaz común: Si Interfaz común Plus (CI+): Si Versión Common interface Plus (CI+): 1.4 Número de puertos HDMI: 4 PC (D-Sub): No Control de electrónica de consumo (CEC): SimpLink Características de administración Tipo de control: Inalámbrico Control por voz: Si Guía electrónica de programación: Si Periodo de programación: 8 día(s) Exhibición en pantalla (OSD): Si Número de lenguajes OSD: 37 modo hotel: Si Apagado automático: Si Temporizador de apagado: Si Firmware actualizable: Si Firmware actualizable mediante: Red Funciona con Amazon Alexa: Si Funciona con el Asistente de Google: Si Funciona con Samsung Bixby: No Control de energía Clase de eficiencia de energía: B Consumo de energía anual: 205 kWh Consumo energético: 148 W Consumo de energía (inactivo): 0,5 W Voltaje de entrada AC: 100 - 240 V Frecuencia de entrada AC: 50/60 Hz Modo de ahorro de energía: Si Escala de eficiencia energética: A++ a D Características del proveedor País de origen: Corea del Sur Peso y dimensiones Ancho del dispositivo (con soporte): 1235 mm Profundidad dispositivo (con soporte): 287 mm Altura del dispositivo (con soporte): 775 mm Peso (con soporte): 20,8 kg Ancho (sin base): 123,5 cm Profundidad (sin base): 6,9 cm Altura (sin base): 71,6 cm Peso (sin base): 20,4 kg Empaquetado Soporte de sobremesa: Si Cables incluidos: Corriente alterna Mando a distancia: Si Tipo de control remoto: MR20 Incluye mando a distancia Smart Remote: Si Incluye barra de sonido: No Manual electrónico: Si Ancho del paquete: 1360 mm Profundidad del paquete: 162 mm Altura del paquete: 810 mm Peso del paquete: 25,2 kg Tipo de embalaje: Caja', 200, '1302.40', 'LG 55NANO956NA.jpg'),
(26, 'Smart TV', 'Smart TV 8K', 'Samsung QE65Q950TS', 'Exhibición Diagonal de la pantalla: 165,1 cm (65\") Tipo HD: 8K Ultra HD Tecnología de visualización: QLED Forma de la pantalla: Plana Relación de aspecto nativa: 16:9 Tecnología de interpolación de movimiento: PQI (Picture Quality Index) 4700 Resolución de la pantalla: 7680 x 4320 Píxeles Relación de luminosidad máxima: 71% Sintonizador de la TV Tipo de sintonizador: Analógico y digital Formato de señal digital: DVB-C2, DVB-T2 Auto-búsqueda de canal: Si Smart TV Smart TV: Si TV por Internet: Si Sistema operativo instalado: Tizen Grabación diferida (timeshift): Si Duplicación de pantalla: Si Compatible con Apple AirPlay 2: Si HbbTV: Si Audio Potencia estimada RMS: 70 W Subwoofer incorporado: Si Decodificadores incorporados: Dolby Digital Tecnologías de decodificación de audio: Dolby Digital Pulse Multiroom: Si Tecnología de audio multiroom o Sistema de sonido multizona: Samsung Multiroom Link Conexión Wifi: Si Ethernet: Si Wi-Fi Direct: Si Bluetooth: Si Versión de Bluetooth: 4.2 Navegación: Si Navegador web: Si Diseño Montaje VESA: Si Pantalla flexible: No Color del producto: Negro Iluminación ambiental: Si Desempeño Alto Rango Dinámico (HDR): Si Tecnología HDR (High Dynamic Range, Alto rango dinámico): High Dynamic Range 10+ (HDR10 Plus) Modo de juego: Si Funciones de teletexto: Si Función de subtítulos: Si Oscurecimiento local: Si Tecnología de procesamiento de imagen: Samsung Contrast Enhancer Digital Clean View: Si Grabación USB: Si ConnectShare (HDD): Si ConnectShare (USB): Si Puertos e Interfaces Cambio rápido entre entradas HDMI: Si Canal de retorno de audio (ARC): Si Puerto DVI: No Ethernet LAN (RJ-45) cantidad de puertos: 1 Cantidad de puertos USB 2.0: 3 Audio digital, salida optica: 1 Número de puertos RF: 3 Interfaz común Plus (CI+): Si Versión Common interface Plus (CI+): 1.4 Número de puertos HDMI: 4 PC (D-Sub): No Control de electrónica de consumo (CEC): Anynet+ Características de administración Guía de voz: Si Guía electrónica de programación: Si Exhibición en pantalla (OSD): Si Imagen en imagen: Si Apagado automático: Si Funciona con Amazon Alexa: Si Funciona con Samsung Bixby: Si Control de energía Consumo energético: 344 W Consumo de energía (inactivo): 0,5 W Consumo de energía (ahorro): 171 W Consumo de energía (max): 410 W Voltaje de entrada AC: 220 - 240 V Frecuencia de entrada AC: 50/60 Hz Peso y dimensiones Ancho del dispositivo (con soporte): 1433,1 mm Profundidad del dispositivo (con soporte): 261,9 mm Altura del dispositivo (con soporte): 881,1 mm Peso (con soporte): 32,1 kg Ancho (sin base): 143,3 cm Profundidad (sin base): 1,5 cm Altura (sin base): 81,4 cm Peso (sin base): 26,5 kg Empaquetado Cables incluidos: Corriente alterna Mando a distancia: Si Manual electrónico: Si Ancho del paquete: 1625 mm Profundidad del paquete: 205 mm Altura del paquete: 956 mm Peso del paquete: 62,4 kg Tipo de embalaje: Caja Otras características Consumo de energía anual: 477 kWh Clase de eficiencia energética (antigua): D', 200, '1348.99', 'Samsung QE65Q950TS.jpg'),
(27, 'Smart TV', 'Smart TV 8K', 'LG 65NANO956NA', 'Exhibición Diagonal de la pantalla: 165,1 cm (65\") Tipo HD: 8K Ultra HD Tecnología de visualización: NanoCell Forma de la pantalla: Plana Relación de aspecto nativa: 16:9 Resolución de la pantalla: 7680 x 3840 Pixeles Diagonal de pantalla: 164 cm Sintonizador de la TV Tipo de sintonizador: Analógico y digital Formato de señal digital: DVB-S2,DVB-T2 Autobusqueda de canal: Si Smart TV Smart TV: Si TV por Internet: Si Sistema operativo instalado: Web OS Versión de sistema operativo: 5,0 Grabación diferida (timeshift): Si Compatible con Apple AirPlay 2: Si HbbTV: Si Aplicaciones de vídeo: Amazon Prime Video, Apple TV, Guindilla, Disney+, Infinity, Mediaset Play, NetFlix, Now TV, RaiPlay, Rakuten, YouTube, tivùon!, tivùsat 4K Audio Potencia estimada RMS: 40 W Decodificadores incorporados: Dolby Atmos Modos de sonido: AI Sound Pro Enhanced Audio Return Channel (eARC) (Canal de retorno de audio mejorado): Si Conexión Wifi: Si Ethernet: Si Wi-Fi estándares: Wi-Fi 5 (802.11ac) Bluetooth: Si Navegación: Si Navegador web: Si Diseño montaje VESA: Si Interfaz de panel de montaje: 400 x 400 mm Pantalla flexible: No Color del producto: Negro, Acero inoxidable Desempeño Alto Rango Dinámico (HDR): Si Tecnología HDR (High Dynamic Range, Alto rango dinámico): Dolby Vision IQ,Filmmaker Mode,HDR Effect,High Dynamic Range 10 Pro (HDR10 Pro),Hybrid Log-Gamma Pro (HLG Pro) Modo de juego: Si Funciones de teletexto: Si Teletexto: 2000 páginas Estándares de teletexto: Lista, Texto superior Formatos de vídeo compatibles: HEVC,VP9 Formatos de audio soportados: AAC,AC3,AC4,MP2,MP3,PCM,WMA Oscurecimiento local: Si Tecnología de procesamiento de imagen: LG AI Picture Pro,LG Face Enhancing,LG True Color Accuracy Pro AMD FreeSync: No NVIDIA G-SYNC: No Puertos e Interfaces Versión HDMI: 2.1 Canal de retorno de audio (ARC): Si Puerto DVI: No Ethernet LAN (RJ-45) cantidad de puertos: 1 Cantidad de puertos USB 2.0: 3 Video componente (YPbPr/YCbCr) entrada: 1 Audio digital, salida optica: 1 Salidas para auriculares: 1 Número de puertos RF: 2 Interfaz común: Si Interfaz común Plus (CI+): Si Versión Common interface Plus (CI+): 1.4 Número de puertos HDMI: 4 PC (D-Sub): No Control de electrónica de consumo (CEC): SimpLink Características de administración Tipo de control: Inalámbrico Guía electrónica de programación: Si Periodo de programación: 8 día(s) Exhibición en pantalla (OSD): Si Número de lenguajes OSD: 37 modo hotel: Si Funciona con Amazon Alexa: Si Funciona con el Asistente de Google: Si Control de energía Clase de eficiencia de energía: B Consumo de energía anual: 252 kWh Consumo energético: 182 W Consumo de energía (inactivo): 0,5 W Voltaje de entrada AC: 100 - 240 V Frecuencia de entrada AC: 50/60 Hz Modo de ahorro de energía: Si Escala de eficiencia energética: A++ to D Peso y dimensiones Ancho: 1454 mm Profundidad: 68,9 mm Altura: 840 mm Ancho del dispositivo (con soporte): 1454 mm Profundidad dispositivo (con soporte): 287 mm Peso: 27 kg Altura del dispositivo (con soporte): 900 mm Peso con stand: 28,1 kg Empaquetado Soporte de sobremesa: Si Cables incluidos: Corriente alterna Mando a distancia: Si Tipo de control remoto: MR20 Incluye barra de sonido: No Ancho del paquete: 1600 mm Profundidad del paquete: 175 mm Altura del paquete: 970 mm Peso del paquete: 35 kg Tipo de embalaje: Caja', 200, '1495.00', 'LG 65NANO956NA.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idusuario` int(11) NOT NULL,
  `nombreusuario` varchar(250) DEFAULT NULL,
  `contrasena` varchar(250) DEFAULT NULL,
  `tipousuario` varchar(7) DEFAULT NULL,
  `imagenusuario` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusuario`, `nombreusuario`, `contrasena`, `tipousuario`, `imagenusuario`) VALUES
(1, 'kizaru', '$2y$10$rpU1QTOU4eNxTQfNpPYtOOolzb9kCdaSW743ZuzNZdmP4yop/RU1S', 'usuario', 'kizaru.png'),
(2, 'akainu', '$2y$10$OHQsJWv.lLPC1MlZZkBah.OdFQWywoNDO7A/gfnOakr6mTJEPcle2', 'usuario', 'akainu.png'),
(3, 'kuzan', '$2y$10$xvp4qGaDkofjR0/gAItM4ugU1cz.fXOW6HY42gdSUjdmWJ4RFHcgi', 'usuario', 'kuzan.png'),
(4, 'cocodrilo', '$2y$10$krmi/7oTCdmHz0XUSD.61u4lEQtEhfrux.0u9iFWLiEK0yZuM7C1G', 'usuario', 'cocodrilo.png'),
(5, 'ace', '$2y$10$vRXwvieFe.yHXjBNlon26ObKmdQyunIkd0ZrmqGRZoQ3pd9E2Txnu', 'usuario', 'ace.png'),
(6, 'teach', '$2y$10$MvNQ5RNpVJQVw/NoMy8sf.egAgwHzNv9.HydXS.r7IWMKEGDVT93G', 'usuario', 'teach.png'),
(7, 'chopper', '$2y$10$YnkcaQnQ86NgOEiTei0FA.xOkN0DFFbDfyJMYfViaZcWCYbKXYBnm', 'usuario', 'chopper.png'),
(8, 'lucci', '$2y$10$lA9DI69GD4TtDm/7eWL0eOzVLR7WkEod4pRiOFh2xYuyfrvTX984S', 'usuario', 'lucci.png'),
(9, 'minotauro', '$2y$10$KCLkTwiy4/KtlpJ68BjbUuE5cJku.aIptkVW7HPQKBycIQotl5Ice', 'admin', 'minotauro.png'),
(10, 'luffy', '$2y$10$od8g5JU5.ZEGEm/f3LxRDuV9h5Vzt4qpEqK8F2/XRGSaheTJJXq2K', 'usuario', 'luffy.png'),
(11, 'doflamingo', '$2y$10$p7aS2I1IhnHTZyfmz63/g.ERKGO3682Rq2JtTypN/D7qDlQb9IEum', 'admin', 'doflamingo.png'),
(12, 'bullet', '$2y$10$2dSNeImoMEr3bZtLFH7qlutXkRaholTdjcgjs/LrFxYBDGIdKtVvi', 'admin', 'bullet.png'),
(13, 'tesoro', '$2y$10$oxUyHBygUFO2FW1xxx09v.MIvE1D6b6wTyvftu0wxRIaKXe1fsrp2', 'admin', 'tesoro.png'),
(22, 'ann', '$2y$10$nH6gZk87gQ0SiRUH9BOxpeSRs70xiG/1GIEJkWsq9B1T4jOcbvaKu', 'usuario', 'ann.png'),
(23, 'david', '$2y$10$wd2f1dvHiB1aZ6JYfoylvuEeK5iPzvv4fohnJ601XfxDeJDXZT7QO', 'usuario', 'Diagrama De Clases.PNG'),
(24, 'david1', '$2y$10$rApI.gehjS8DbxE3FGZh0Oajp1m7yS4oGtbZ1567AaXdZnuWE7Jhq', 'usuario', 'teach.png');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carritotienda`
--
ALTER TABLE `carritotienda`
  ADD PRIMARY KEY (`idcarrito`);

--
-- Indices de la tabla `comentariosproductos`
--
ALTER TABLE `comentariosproductos`
  ADD PRIMARY KEY (`idcomentario`);

--
-- Indices de la tabla `comentariostienda`
--
ALTER TABLE `comentariostienda`
  ADD PRIMARY KEY (`idcomentario`);

--
-- Indices de la tabla `facturas`
--
ALTER TABLE `facturas`
  ADD PRIMARY KEY (`idfactura`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`idpago`);

--
-- Indices de la tabla `productostienda`
--
ALTER TABLE `productostienda`
  ADD PRIMARY KEY (`idproducto`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idusuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carritotienda`
--
ALTER TABLE `carritotienda`
  MODIFY `idcarrito` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT de la tabla `comentariosproductos`
--
ALTER TABLE `comentariosproductos`
  MODIFY `idcomentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT de la tabla `comentariostienda`
--
ALTER TABLE `comentariostienda`
  MODIFY `idcomentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `facturas`
--
ALTER TABLE `facturas`
  MODIFY `idfactura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `idpago` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT de la tabla `productostienda`
--
ALTER TABLE `productostienda`
  MODIFY `idproducto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
