<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Tienda De Tecnologia</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="EstilosTienda.css">
    <style>
        #menu input[type=submit] {
            box-shadow: 2px 2px 0 black;
        }
    </style>
    <script type="text/javascript">
        function actualizapag() {
            location.reload(true);
        }
    </script>
</head>
<body>
<?php
require_once "Controlador/Controlador.php"; // Incluyo la direccion al Controlador
if ($inserta) { // Si un producto se inserta correctamente salta el mensaje
    echo "<script>alert('Producto insertado con exito');</script>";
}
if ($cancelar) { // Si pulso en cancelar al intentar borrar el producto salta el mensaje
    echo "<script>alert('Has cancelado borrar el producto');</script>";
}
if ($borrado) { // Si un producto se borra correctamente salta el mensaje
    echo "<script>alert('Producto borrado con exito');</script>";
}
if ($actualizado) { // Si un producto se actualiza correctamente salta el mensaje
    echo "<script>alert('Producto actualizado con exito');</script>";
}
if ($incompleto) { // Si no has seleccionado correctamente salta el mensaje
    echo "<script>alert('Selecciona correctamente');</script>";
}
if ($nocompleto) { // Si no has seleccionado un producto correctamente salta el mensaje
    echo "<script>alert('Selecciona el tipo de producto correctamente');</script>";
}
if ($nada) { // Si no hay un producto salta el mensaje
    echo "<script>alert('No hay ningun campo');</script>";
}
if ($registrar) { // Si un usuario se inserta correctamente salta el mensaje
    echo "<script>alert('Usuario registrado con exito');</script>";
}
if ($noregistrado) { // Si un usuario no se inserta correctamente salta el mensaje
    echo "<script>alert('Usuario no registrado');</script>";
}
if ($iniciar) { // Si un usuario y su contraseña no son correctos salta el mensaje
    echo "<script>alert('Usuario o contraseña incorrectos');</script>";
}
?>
</body>
</html>