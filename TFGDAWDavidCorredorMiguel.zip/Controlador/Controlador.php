<?php
// Incluyo la direccion de los Modelos
require_once "Modelo/ProductosModelo.php";
require_once "Modelo/ComentariosModelo.php";
require_once "Modelo/CarritoModelo.php";
require_once "Modelo/UsuariosModelo.php";
$p0 = new ProductosModelo(); // Creo un nuevo objeto ProductosModelo
$p = new ProductosModelo();
$f = new CarritoModelo(); // Creo un nuevo objeto CarritoModelo
$c = new ComentariosModelo(); // Creo un nuevo objeto ComentariosModelo
$usuarios = new UsuariosModelo(); // Creo un nuevo objeto UsuariosModelo
// Creo las variables globales
$pagina = $numpag = $comentPorPag = $comentPorPagp = 1;
$vector = array();
$paginaactual = $total = 0;
$tipousuario = "";
$header0 = $acceso0 = $footer0coment = $paginacion = true;
$nocompleto = $nada = $acceso = $registrar = $noregistrado = $iniciar = $inserta = $borrarSeguro = $cancelar =
$borrado = $actualizado = $incompleto = $acceso2coment = $acceso3coment = $accesosesion = $crearsesion = $header1 =
$acceso1 = $footer1coment = $accesoimagen = $cambiaimagen = $detallesproducto = $acceso2a = $acceso2b = $acceso3a =
$acceso3b = $acceso4 = $acceso5a = $acceso5b = $acceso6 = $insertacomentariotienda = $insertacomentarioprod =
$insertacesta = $insertafactura = $insertatotalcesta = $borrap = $vaciacesta = $actualizacompra = false;
$tipos = $p->sacaTipo(); // Cargo los tipos de productos
$subtipos = $p->sacaSubtipo(); // Cargo los subtipos de productos
$vectori = $p->getInfoGeneral(); // Muestro la información de la pagina
if (isset($_GET["paginacoment"])) { // Muestro los comentarios de la pagina por paginacion
    $pagina = $_GET["paginacoment"];
}
$vectorcomt = $c->getTotalComentarios();
$totalComentarios = $vectorcomt['totalcomentarios'];
$numpagcoment = ceil($totalComentarios / $comentPorPag);
$vectorcomt = $c->getComentarioTienda($totalComentarios, $comentPorPag, $numpagcoment, $pagina);
session_start(); // Inicio sesión
if (isset($_SESSION["user"])) { // Muestro la imagen del usuario
    $imagenusuarios = $usuarios->getImagenUsuario();
}
if (isset($_GET["pagina"])) {
    $pagina = $_GET["pagina"];
}
$prodPorPag = $resultadopagina = 9;
// Muestro los productos sin sesión
$vectorp0 = $p0->getTotalProductos();
$totalProductos = $vectorp0['total'];
$numpag = ceil($totalProductos / $prodPorPag);
$vectorp0 = $p0->getProductos($totalProductos, $prodPorPag, $numpag, $pagina);
// Muestro los comentarios
$totalProductos = $total;
$numpag = ceil($totalProductos / $resultadopagina);
// Muestro los productos con sesión
$vectorp = $p->getTotalProductos();
$totalProductos = $vectorp['total'];
$numpag = ceil($totalProductos / $prodPorPag);
if (isset($_POST["detalles0"]) || isset($_POST["detalles"]) || isset($_POST["comentariosp0"])
    || isset($_POST["comentariosp"])) { // Muestro detalles del producto
    $detallesproducto = $p->detallesProductos($_GET["nombre"]);
    $vectorcomtp = $c->getTotalComentariosProductos();
    $totalComentariosp = $vectorcomtp['totalcomentariosp'];
    $numpagcomentp = ceil($totalComentariosp / $comentPorPagp);
    $vectorcomtp = $c->getComentarioTiendaProductos($_GET["nombre"], $totalComentariosp, $comentPorPagp,
        $numpagcomentp, $pagina);
}
if (isset($_POST["detalles0"])) { // Detalles del producto sin sesión
    $acceso0 = $paginacion = false;
    $acceso2a = true;
}
if (isset($_POST["comentariost0"])) { // Muestro los comentarios de la tienda sin sesión
    $acceso0 = $paginacion = false;
    $acceso3coment = true;
    $vectorcomentt = $c->totalComentariosTienda();
}
if (isset($_POST["comentariosp0"])) { // Comentarios del producto sin sesión
    $acceso0 = $paginacion = false;
    $acceso2coment = true;
    $vectorcomentp = $c->totalComentariosProductos($_GET["nombre"]);
}
if (isset($_GET["logout"])) { // Cierro la sesión
    session_start();
    session_destroy();
    setcookie("user", "", time() - 1, "/");
    header("location:Index.php");
}
if (isset($_POST["buscar0"])) { // Muestro los productos por tipo sin sesión
    if ($_POST["tipovalor"] == "Tipo De Producto: ") {
        $nocompleto = true;
    } else {
        $acceso0 = $paginacion = false;
        $acceso3a = true;
        $vector = $p->buscatipoProducto();
    }
}
if (isset($_POST["buscarsubtipo0"])) { // Muestro los productos por subtipo sin sesión
    $acceso0 = $paginacion = false;
    $acceso3a = true;
    $vector = $p->buscasubtipoProducto();
}
if (isset($_COOKIE["user"])) { // Busco al usuario en la base de datos
    $acceso = true;
    $tipousuario = $usuarios->consultarPerfil($_COOKIE["user"]);
} else if (isset($_SESSION["user"])) {
    $acceso = true;
    $tipousuario = $usuarios->consultarPerfil($_SESSION["user"]);
}
if (isset($_POST["iniciasesion"])) { // Muestro el formulario para iniciar sesión
    $header0 = $acceso0 = $footer0coment = $paginacion = false;
    $accesosesion = true;
}
if (!$acceso) { // Muestro el formulario para crear usuario
    if (isset($_GET["option"])) {
        $header0 = $acceso0 = $footer0coment = $accesosesion = $paginacion = false;
        if ($_GET["option"] == "registrar") {
            if (isset($_POST["registrar"])) {
                if ($_POST["userR"] != "" || $_POST["passR"] != "") {
                    $registrar = $usuarios->registraUser();
                } else {
                    $crearsesion = $noregistrado = true;
                }
            }
            $crearsesion = true;
        }
    } else {
        if (isset($_POST["iniciar"])) { // Inicio sesión con nombre de usuario y productos
            $iniciar = $usuarios->consultaUser();
            $imagenusuarios = $usuarios->getImagenUsuario(); // Muestro la imagen del usuario
            if (!$iniciar) {
                $header0 = $acceso0 = $footer0coment = false;
                $header1 = $acceso1 = $footer1coment = true;
                ?>
                <script type="text/javascript">window.onload = actualizapag();</script>
                <?php
                $vectorp = $p->getProductos($totalProductos, $prodPorPag, $numpag, $pagina);
            } else {
                $header0 = $acceso0 = $footer0coment = false;
                $header1 = $acceso1 = $footer1coment = $accesosesion = true;
            }
        }
    }
} else {
    $header0 = $acceso0 = $footer0coment = false;
    $header1 = $acceso1 = $footer1coment = true;
    if (isset($_POST["buscar"]) || isset($_POST["buscarsubtipo"])) {} else {
        $vectorp = $p->getProductos($totalProductos, $prodPorPag, $numpag, $pagina);
    }
    if (isset($_GET["idproducto"])) { // Si es admin borra, actualiza o inserta productos en la base de datos
        if (isset($_POST["borrar"])) {
            $borrarSeguro = true;
        } else if (isset($_POST["actualizar"])) {
            $buscaActualizar = $p->buscatipoProductos($_GET["idproducto"]);
        } else if (isset($_POST["borrar2"])) {
            $borrado = $p->borrarProductos($_GET["idproducto"]);
        } else if (isset($_POST["cancelar"])) {
            $cancelar = true;
        } else if (isset($_POST["actualizar2"])) {
            $actualizado = $p->actualizaProductos($_GET["idproducto"]);
        }
    }
    if (isset($_POST["insertar"])) {
        $inserta = $p->insertarProducto();
    }
    if (isset($_POST["cambiaimagen"])) { // Muestro el formulario para cambiar imagen
        $acceso1 = $paginacion = false;
        $accesoimagen = true;
    }
    if (isset($_POST["cambiarimagen"])) { // Cambio la imagen y vuelvo a inicio
        $cambiaimagen = $usuarios->cambiaImagenUsuario();
        header("location:Index.php");
    }
    if (isset($_POST["buscar"])) { // Muestro los productos por tipo
        if ($_POST["tipovalor"] == "Tipo De Producto: ") {
            $nocompleto = true;
        } else {
            $acceso1 = $paginacion = false;
            $acceso3b = true;
            $vector = $p->buscatipoProducto();
        }
    }
    if (isset($_POST["buscarsubtipo"])) { // Muestro los productos por subtipo
        $acceso1 = $paginacion = false;
        $acceso3b = true;
        $vector = $p->buscasubtipoProducto();
    }
    if (isset($_POST["detalles"])) { // Detalles del producto con sesión
        $acceso1 = $paginacion = false;
        $acceso2b = true;
    }
    if (isset($_POST["enviacomentariotienda"])) { // Envío el comentario y valoración
        $insertacomentariotienda = $c->insertarComentarioTienda();
    }
    if (isset($_POST["comentariost"])) { // Muestro los comentarios de la tienda con sesión
        $acceso1 = $paginacion = false;
        $acceso3coment = true;
        $vectorcomentt = $c->totalComentariosTienda();
    }
    if (isset($_POST["comentariosp"])) { // Muestra el comentario y valoración del producto
        $acceso1 = $paginacion = false;
        $acceso2coment = true;
        $vectorcomentp = $c->totalComentariosProductos();
    }
    if (isset($_POST["enviacomentarioprod"])) { // Envía el comentario y valoración del producto
        $insertacomentariotienda = $c->insertarComentarioProducto();
    }
    if (isset($_POST["anadecesta"])) { // Añado a la cesta el producto
        $insertacesta = $f->insertarCesta($_POST["nombreusuario"], $_POST["idproductocesta"], $_POST["subtipocesta"],
            $_POST["nombrecesta"], $_POST["cantidadcesta"], $_POST["preciocesta"], $_POST["imagencesta"]);
    }
    if (isset($_POST["vercesta"])) { // Muestro los productos de la cesta del usuario
        $acceso1 = $paginacion = false;
        $acceso4 = true;
        $vectorc = $f->getCesta($_SESSION["user"]); // Productos de cesta
        $totalprecio = $f->totalPrecioCesta($_SESSION["user"]); // Total de productos de cesta
    }
    if (isset($_POST["vaciacesta"])) { // Borro todos los productos de la cesta del usuario
        $acceso4 = false;
        $vaciacesta = $f->vaciaCesta($_SESSION["user"]);
    }
    if (isset($_POST["comprar"])) { // Muestro el formulario para seleccionar tarjeta
        $acceso1 = $paginacion = false;
        $acceso5a = true;
        $numerotajeta = $f->sacaNumTarjeta($_SESSION["user"]); // Numero tarjeta del usuario
    }
    if (isset($_POST["insertanuevatarjeta"])) { // Muestro el formulario para insertar una nueva tarjeta
        $acceso1 = $acceso5a = $acceso6 = $paginacion = false;
        $acceso5b = true;
        $numerotajeta = $f->sacaNumTarjeta($_SESSION["user"]); // Numero tarjeta del usuario
    }
    if (isset($_POST["insertatarjeta"])) { // Inserto la nueva tarjeta con o sin telefono
        $acceso1 = $acceso5b = $acceso6 = $paginacion = false;
        $acceso5a = true;
        $numerotajeta = $f->sacaNumTarjeta($_SESSION["user"]); // Numero tarjeta del usuario
        if ($_POST["numerotarjeta"] == "") {
            $incompleto = true;
        } else {
            if ($_POST["telefono"] == "") {
                $nuevopago = $f->insertarPago($_POST["usuariotarjeta"], $_POST["nombreyapellidos"],
                    $_POST["direccion"], $_POST["poblacion"], $_POST["provincia"], $_POST["codigopostal"],
                    $_POST["numerotarjeta"], $_POST["mes"], $_POST["ano"]);
            } else {
                $nuevopagotel = $f->insertarPagoTel($_POST["usuariotarjeta"], $_POST["nombreyapellidos"],
                $_POST["direccion"], $_POST["poblacion"], $_POST["provincia"], $_POST["codigopostal"],
                $_POST["numerotarjeta"], $_POST["mes"], $_POST["ano"], $_POST["telefono"]);
            }
        }
    }
    if (isset($_POST["borrap"])) { // Borra el producto seleccionado
        $borrap = $f->borrarProductoCesta();
        $acceso1 = $paginacion = false;
        $acceso4 = true;
    }
    if (isset($_POST["continuarpago"])) { // Muestro el formulario para finalizar el pago
        $numerotajeta = $f->sacaNumTarjeta($_SESSION["user"]); // Numero tarjeta del usuario
        $vectorctp = $f->buscarPago($_SESSION["user"]);
        if (!$vectorctp) {
            $incompleto = $acceso1 = $acceso5b = $acceso6 = $paginacion = false;
            $acceso5a = true;
        } else {
            $acceso1 = $acceso5a = $acceso5b = $paginacion = false;
            $acceso6 = true;
            $vectorc = $f->getCesta($_SESSION["user"]); // Productos de cesta
            $vectorct = $f->getCesta($_SESSION["user"]); // Productos de cesta con total
            $totalprecio = $f->totalPrecioCesta($_SESSION["user"]); // Total de productos de cesta
        }
    }
    if (isset($_POST["descargafactura"])) { // Inserto total pago del usuario y descargo archivo de su factura
        $acceso6 = false;
        $insertatotalcesta = $f->insertarTotalPago();
        $insertafactura = $f->insertarProductosFactura($_POST["idpago"], $_SESSION["user"]);
        $acceso6 = true;
    }
    if (isset($_POST["finaliza"])) { // Actualizo cantidad de productos de la tienda y los elimino de su cesta
        header("location:Index.php");
        $actualizacompra = $f->compraProductos();
        $vaciacesta = $f->vaciaCesta($_SESSION["user"]);
    }
}
// Incluyo la direccion de los archivos de la carpeta Vista
require_once "Vista/Menus.php";
require_once "Vista/Tienda.php";
require_once "Vista/TiendaSinSesion.php";
require_once "Vista/UsuarioTienda.php";
require_once "Vista/CrearUsuarioTienda.php";
require_once "Vista/TarjetaPago.php";
require_once "Vista/FooterComentarios.php";
?>