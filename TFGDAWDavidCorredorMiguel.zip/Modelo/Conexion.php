<?php
require_once "Configuracion.php"; // Incluyo la direccion de la Configuracion
class Conexion {
    public static function conectar() {
        try { // Creo un nuevo PDO y paso las variables de la Configuracion
            $cn = new PDO("mysql:host=" . DB_HOST . "; dbname=" . DB_NAME,
                DB_USERNAME, DB_PASSWORD);
            $cn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $cn->exec("set character set " . DB_CHARSET);
        } catch (Exception $ex) { // Si falla la conexión muestra el mensaje
            die(" Ha ocurrido algun error en la conexion. ERROR: " . $ex->getMessage());
        }
        return $cn;
    }
}
?>