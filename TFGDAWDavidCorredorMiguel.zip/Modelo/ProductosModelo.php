<?php
class ProductosModelo { // Creo las variables globales y privadas
    private $db;
    private $productos;
    private $infog;
    public function __construct() { // Creo el constructor e incluyo la direccion de la Conexion
        require_once "Conexion.php";
        $this->db = Conexion::conectar();
        $this->productos = array();
        $this->infog = array();
    }
    public function getTotalProductos() { // Función para ver total de productos
        $consulta = "select count(*) as 'total' from productostienda where cantidad > 0";
        $resultados = $this->db->prepare($consulta);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                $reg = $resultados->fetch(PDO::FETCH_ASSOC);
                return $reg;
            }
        }
    }
    // Función para ver lista de productos
    public function getProductos($totalProductos, $prodPorPag, $numpag, $pagina) {
        $start = ($pagina - 1) * $prodPorPag;
        $consulta = "select * from productostienda limit $start, $prodPorPag";
        $resultados = $this->db->prepare($consulta);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                while ($reg = $resultados->fetch(PDO::FETCH_ASSOC)) {
                    $this->productos[] = $reg;
                }
                return $this->productos;
            }
        }
    }
    public function getInfoGeneral() { // Función para ver información de la pagina
        $consulta = "select * from infogeneral";
        $resultados = $this->db->prepare($consulta);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                while ($reg = $resultados->fetch(PDO::FETCH_ASSOC)) {
                    $this->infog[] = $reg;
                }
                return $this->infog;
            }
        }
    }
    public function detallesProductos($nombre) { // Función para ver detalle del producto por nombre
        $consulta = "select * from productostienda where nombre=:nombre";
        $nombre = htmlentities(addslashes($nombre));
        $resultados = $this->db->prepare($consulta);
        $resultados->bindParam(":nombre", $nombre);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                $reg = $resultados->fetch(PDO::FETCH_ASSOC);
                return $reg;
            }
        }
    }
    public function sacaTipo() { // Función para ver listado los tipos de productos
        $consulta = "select distinct tipo as 'tipovalor' from productostienda";
        $resultados = $this->db->prepare($consulta);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                while ($reg = $resultados->fetch(PDO::FETCH_ASSOC)) {
                    $tipos[] = $reg["tipovalor"];
                }
                return $tipos;
            }
        }
    }
    public function sacaSubtipo() { // Función para ver listado los subtipos de productos
        $consulta = "select distinct subtipo as 'subtipovalor' from productostienda";
        $resultados = $this->db->prepare($consulta);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                while ($reg = $resultados->fetch(PDO::FETCH_ASSOC)) {
                    $tipos[] = $reg["subtipovalor"];
                }
                return $tipos;
            }
        }
    }
    // Función para ver lista de productos buscados con ese tipo
    public function buscatipoProducto() {
        $consulta = "select * from productostienda where tipo = ?";
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(1, $_POST["tipovalor"]);
        if ($resultado->execute()) {
            if ($resultado->rowCount() > 0) {
                while ($reg = $resultado->fetch(PDO::FETCH_ASSOC)) {
                    $this->productos[] = $reg;
                }
                return $this->productos;
            }
        }
    }
    // Función para ver lista de productos buscados con ese subtipo
    public function buscasubtipoProducto() {
        $consulta = "select * from productostienda where subtipo = ?";
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(1, $_GET["subtipo"]);
        if ($resultado->execute()) {
            if ($resultado->rowCount() > 0) {
                while ($reg = $resultado->fetch(PDO::FETCH_ASSOC)) {
                    $this->productos[] = $reg;
                }
                return $this->productos;
            }
        }
    }
    public function insertarProductos() { // Función para insertar nuevo producto
        $consulta = "INSERT INTO productostienda(tipo, subtipo, nombre, descripcion, cantidad, precio, imagen) 
                        VALUES (:tipo, :subtipo, :nombre, :descripcion, :cantidad, :precio, :imagen)";
        $tipo = htmlentities(addslashes($_POST["tipo"]));
        $subtipo = htmlentities(addslashes($_POST["subtipo"]));
        $nombre = htmlentities(addslashes($_POST["nombre"]));
        $descripcion = htmlentities(addslashes($_POST["descripcion"]));
        $cantidad = htmlentities(addslashes($_POST["cantidad"]));
        $precio = htmlentities(addslashes($_POST["precio"]));
        $imagen = $_FILES["imagen"]["name"];
        $carpetadestino = $_SERVER["DOCUMENT_ROOT"] . "/Trabajo Fin De Grado David Corredor Miguel/imagenes/";
        move_uploaded_file($_FILES["imagen"]["tmp_name"], $carpetadestino . $imagen);
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(":tipo", $tipo);
        $resultado->bindParam(":subtipo", $subtipo);
        $resultado->bindParam(":nombre", $nombre);
        $resultado->bindParam(":descripcion", $descripcion);
        $resultado->bindParam(":cantidad", $cantidad);
        $resultado->bindParam(":precio", $precio);
        $resultado->bindParam(":imagen", $imagen);
        return $resultado->execute();
    }
    public function borrarProductos($idproducto) { // Función para borrar producto por id
        $consulta = "delete from productostienda WHERE idproducto=:idproducto";
        $idproducto = htmlentities(addslashes($idproducto));
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(":idproducto", $idproducto);
        return $resultado->execute();
    }
    public function buscaProductos($idproducto) { // Función para buscar producto por id
        $consulta = "select * from productostienda WHERE idproducto=:idproducto";
        $idproducto = htmlentities(addslashes($idproducto));
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(":idproducto", $idproducto);
        if ($resultado->execute()) {
            if ($resultado->rowCount() > 0) {
                $reg = $resultado->fetch(PDO::FETCH_ASSOC);
                return $reg;
            }
        }
    }
    public function actualizaProductos($idproducto) { // Función para actualizar producto por id
        $consulta = "UPDATE productostienda SET tipo=:tipo, subtipo=:subtipo, nombre=:nombre, 
        descripcion=:descripcion, cantidad=:cantidad, precio=:precio, imagen=:imagen WHERE idproducto=:idproducto";
        $tipo = htmlentities(addslashes($_POST["tipo"]));
        $subtipo = htmlentities(addslashes($_POST["subtipo"]));
        $nombre = htmlentities(addslashes($_POST["nombre"]));
        $descripcion = htmlentities(addslashes($_POST["descripcion"]));
        $cantidad = htmlentities(addslashes($_POST["cantidad"]));
        $precio = htmlentities(addslashes($_POST["precio"]));
        $imagen = $_FILES["imagen"]["name"];
        $carpetadestino = $_SERVER["DOCUMENT_ROOT"] . "/Trabajo Fin De Grado David Corredor Miguel/imagenes/";
        move_uploaded_file($_FILES["imagen"]["tmp_name"], $carpetadestino . $imagen);
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(":tipo", $tipo);
        $resultado->bindParam(":subtipo", $subtipo);
        $resultado->bindParam(":nombre", $nombre);
        $resultado->bindParam(":descripcion", $descripcion);
        $resultado->bindParam(":cantidad", $cantidad);
        $resultado->bindParam(":precio", $precio);
        $resultado->bindParam(":imagen", $imagen);
        $resultado->bindParam(":idproducto", $idproducto);
        return $resultado->execute();
    }
}
?>