<?php
// Defino las variables que se usaran en la Conexion
define("DB_HOST", "localhost");
define("DB_USERNAME", "root");
define("DB_PASSWORD", "");
define("DB_NAME", "tfgdavidc");
define("DB_CHARSET", "utf8");
?>