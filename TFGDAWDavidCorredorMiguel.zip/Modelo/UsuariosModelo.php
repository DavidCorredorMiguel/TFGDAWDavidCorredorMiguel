<?php
class UsuariosModelo { // Creo las variables globales y privadas
    private $db;
    private $usuarios;
    public function __construct() { // Creo el constructor e incluyo la direccion de la Conexion
        require_once "Conexion.php";
        $this->db = Conexion::conectar();
        $this->usuarios = array();
    }
    public function getImagenUsuario() { // Función para ver imagen del usuario
        $consulta = "select * from usuarios where nombreusuario=:nombreusuario";
        $nombreusuario = htmlentities(addslashes($_SESSION["user"]));
        $resultados = $this->db->prepare($consulta);
        $resultados->bindParam(":nombreusuario", $nombreusuario);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                while ($reg = $resultados->fetch(PDO::FETCH_ASSOC)) {
                    $this->usuarios[] = $reg;
                }
                return $this->usuarios;
            }
        }
    }
    public function cambiaImagenUsuario() { // Función para cambiar imagen del usuario
        $consulta = "UPDATE usuarios SET imagenusuario=:imagenusuario WHERE nombreusuario=:nombreusuario";
        $nombreusuario = htmlentities(addslashes($_SESSION["user"]));
        $imagenusuariocambia = $_FILES["imagenusuariocambia"]["name"];
        $carpetadestino = $_SERVER["DOCUMENT_ROOT"] .
            "/Trabajo Fin De Grado David Corredor Miguel/imagenesusuarios/";
        move_uploaded_file($_FILES["imagenusuariocambia"]["tmp_name"], $carpetadestino . $imagenusuariocambia);
        $resultados = $this->db->prepare($consulta);
        $resultados->bindParam(":imagenusuario", $imagenusuariocambia);
        $resultados->bindParam(":nombreusuario", $nombreusuario);
        return $resultados->execute();
    }
    public function registraUser() { // Función para crear nuevo usuario
        $consulta = "insert into usuarios (nombreusuario, contrasena, tipousuario, imagenusuario) 
        values (:nombreusuario, :contrasena, :tipousuario, :imagenusuario)";
        $nombreusuario = htmlentities(addslashes($_POST["userR"]));
        $contrasena = htmlentities(addslashes($_POST["passR"]));
        $hash = password_hash($contrasena, PASSWORD_DEFAULT);
        $tipousuario = "usuario";
        $newimagenusuario = $_FILES["newimagenusuario"]["name"];
        $carpetadestino = $_SERVER["DOCUMENT_ROOT"] . "/Trabajo Fin De Grado David Corredor Miguel/imagenesusuarios/";
        move_uploaded_file($_FILES["newimagenusuario"]["tmp_name"], $carpetadestino . $newimagenusuario);
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(":nombreusuario", $nombreusuario);
        $resultado->bindParam(":contrasena", $hash);
        $resultado->bindParam(":tipousuario", $tipousuario);
        $resultado->bindParam(":imagenusuario", $newimagenusuario);
        return $resultado->execute();
    }
    public function consultaUser() { // Función para ver si hay usuario
        $consulta = "select * from usuarios where nombreusuario=:nombreusuario";
        $nombreusuario = htmlentities(addslashes($_POST["user"]));
        $contrasena = htmlentities(addslashes($_POST["pass"]));
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(":nombreusuario", $nombreusuario);
        if ($resultado->execute()) {
            if ($resultado->rowCount() > 0) {
                $reg = $resultado->fetch(PDO::FETCH_ASSOC);
                if (password_verify($contrasena, $reg["contrasena"])) {
                    if (isset($_POST["recuerda"])) {
                        setcookie("user", $nombreusuario, time() + 3600, "/");
                    }
                    $_SESSION["user"] = $nombreusuario;
                    return false;
                } else {
                    return true;
                }
            } else {
                return true;
            }
        }
    }
    public function consultarPerfil($nombreusuario) { // Función para ver tipo de usuario
        $consulta = "select * from usuarios where nombreusuario=:nombreusuario";
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(":nombreusuario", $nombreusuario);
        if ($resultado->execute()) {
            if ($resultado->rowCount() > 0) {
                $reg = $resultado->fetch(PDO::FETCH_ASSOC);
                return $reg["tipousuario"];
            }
        }
    }
}
?>