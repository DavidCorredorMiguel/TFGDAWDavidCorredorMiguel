<?php
class CarritoModelo { // Creo las variables globales y privadas
    private $db;
    private $productos;
    public function __construct() { // Creo el constructor e incluyo la direccion de la Conexion
        require_once "Conexion.php";
        $this->db = Conexion::conectar();
        $this->productos = array();
        $this->pagos = array();
    }
    // Función para insertar productos en la cesta
    public function insertarCesta($nombreusuario, $idproducto, $subtipocesta, $nombrecesta,
                                  $cantidadcesta, $preciocesta, $imagencesta) {
        if ($cantidadcesta > 0) {
            $consulta = "INSERT INTO carritotienda(nombreusuario, idproducto, subtipoproducto, 
            nombreproducto, cantidadproducto, precioproducto, imagenproducto, totalproducto) 
            VALUES (:nombreusuario, :idproducto, :subtipocesta, :nombrecesta, :cantidadcesta, 
            :preciocesta, :imagencesta, :totalproducto)";
            $nombreusuario = htmlentities(addslashes($nombreusuario));
            $idproducto = htmlentities(addslashes($idproducto));
            $subtipocesta = htmlentities(addslashes($subtipocesta));
            $nombrecesta = htmlentities(addslashes($nombrecesta));
            $cantidadcesta = htmlentities(addslashes($cantidadcesta));
            $preciocesta = htmlentities(addslashes($preciocesta));
            $imagencesta = htmlentities(addslashes($imagencesta));
            $totalproducto = $cantidadcesta * $preciocesta;
            $resultado = $this->db->prepare($consulta);
            $resultado->bindParam(":nombreusuario", $nombreusuario);
            $resultado->bindParam(":idproducto", $idproducto);
            $resultado->bindParam(":subtipocesta", $subtipocesta);
            $resultado->bindParam(":nombrecesta", $nombrecesta);
            $resultado->bindParam(":cantidadcesta", $cantidadcesta);
            $resultado->bindParam(":preciocesta", $preciocesta);
            $resultado->bindParam(":imagencesta", $imagencesta);
            $resultado->bindParam(":totalproducto", $totalproducto);
            return $resultado->execute();
        } else {
            echo "<script>alert('Selecciona Cantidad Antes De Añadir a La Cesta');</script>";
        }
    }
    public function getCesta($nombreusuario) { // Función para ver total de productos de la cesta
        $consulta = "select * from carritotienda where nombreusuario=:nombreusuario";
        $resultados = $this->db->prepare($consulta);
        $resultados->bindParam(":nombreusuario", $nombreusuario);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                while ($reg = $resultados->fetch(PDO::FETCH_ASSOC)) {
                    $this->productos[] = $reg;
                }
                return $this->productos;
            } else {
                header("location:Index.php");
            }
        }
    }
    public function sacaNumTarjeta($nombreusuario) { // Función para ver listado números de tarjetas del usuario
        $consulta = "select distinct numerotarjeta as 'numtarjeta' from pagos WHERE nombreusuario=:nombreusuario";
        $nombreusuario = htmlentities(addslashes($nombreusuario));
        $resultados = $this->db->prepare($consulta);
        $resultados->bindParam(":nombreusuario", $nombreusuario);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                while ($reg = $resultados->fetch(PDO::FETCH_ASSOC)) {
                    $numerotajeta[] = $reg["numtarjeta"];
                }
                return $numerotajeta;
            }
        }
    }
    // Función para insertar tarjeta con telefono
    public function insertarPagoTel($nombreusuario, $nombreyapellidos, $direccion, $poblacion, $provincia,
                                    $codigopostal, $numerotarjeta, $mes, $ano, $telefono) {
        $consulta = "INSERT INTO pagos(nombreusuario, nombreyapellidos, direccion, poblacion, provincia, 
          codigopostal, numerotarjeta, mes, ano, telefono) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $nombreusuario = htmlentities(addslashes($nombreusuario));
        $nombreyapellidos = htmlentities(addslashes($nombreyapellidos));
        $direccion = htmlentities(addslashes($direccion));
        $poblacion = htmlentities(addslashes($poblacion));
        $provincia = htmlentities(addslashes($provincia));
        $codigopostal = htmlentities(addslashes($codigopostal));
        $numerotarjeta = htmlentities(addslashes($numerotarjeta));
        $mes = htmlentities(addslashes($mes));
        $ano = htmlentities(addslashes($ano));
        $telefono = htmlentities(addslashes($telefono));
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(1, $nombreusuario);
        $resultado->bindParam(2, $nombreyapellidos);
        $resultado->bindParam(3, $direccion);
        $resultado->bindParam(4, $poblacion);
        $resultado->bindParam(5, $provincia);
        $resultado->bindParam(6, $codigopostal);
        $resultado->bindParam(7, $numerotarjeta);
        $resultado->bindParam(8, $mes);
        $resultado->bindParam(9, $ano);
        $resultado->bindParam(10, $telefono);
        return $resultado->execute();
    }
    // Función para insertar tarjeta sin telefono
    public function insertarPago($nombreusuario, $nombreyapellidos, $direccion, $poblacion, $provincia,
                                 $codigopostal, $numerotarjeta, $mes, $ano) {
        $consulta = "INSERT INTO pagos(nombreusuario, nombreyapellidos, direccion, poblacion, provincia, 
          codigopostal, numerotarjeta, mes, ano) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $nombreusuario = htmlentities(addslashes($nombreusuario));
        $nombreyapellidos = htmlentities(addslashes($nombreyapellidos));
        $direccion = htmlentities(addslashes($direccion));
        $poblacion = htmlentities(addslashes($poblacion));
        $provincia = htmlentities(addslashes($provincia));
        $codigopostal = htmlentities(addslashes($codigopostal));
        $numerotarjeta = htmlentities(addslashes($numerotarjeta));
        $mes = htmlentities(addslashes($mes));
        $ano = htmlentities(addslashes($ano));
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(1, $nombreusuario);
        $resultado->bindParam(2, $nombreyapellidos);
        $resultado->bindParam(3, $direccion);
        $resultado->bindParam(4, $poblacion);
        $resultado->bindParam(5, $provincia);
        $resultado->bindParam(6, $codigopostal);
        $resultado->bindParam(7, $numerotarjeta);
        $resultado->bindParam(8, $mes);
        $resultado->bindParam(9, $ano);
        return $resultado->execute();
    }
    public function borrarProductoCesta() { // Función para borrar productos de la cesta
        $consulta = "delete from carritotienda WHERE idproducto=:idproducto";
        $idproducto = htmlentities(addslashes($_POST["idproductocesta"]));
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(":idproducto", $idproducto);
        return $resultado->execute();
    }
    public function totalPrecioCesta($nombreusuario) { // Función para ver total precio de productos
        $consulta = "SELECT SUM(totalproducto) as 'totalprepro' from carritotienda 
        WHERE nombreusuario=:nombreusuario";
        $resultados = $this->db->prepare($consulta);
        $resultados->bindParam(":nombreusuario", $nombreusuario);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                while ($reg = $resultados->fetch(PDO::FETCH_ASSOC)) {
                    $totalprecio[] = $reg["totalprepro"];
                }
                return $totalprecio;
            }
        }
    }
    public function buscarPago($nombreusuario) { // Función para ver número de la tarjeta
        $consultaLimite = "select * from pagos where numerotarjeta = ? and nombreusuario = ?";
        $resultados = $this->db->prepare($consultaLimite);
        $resultados->bindParam(1, $_POST["numtarjeta"]);
        $resultados->bindParam(2, $nombreusuario);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                while ($reg = $resultados->fetch(PDO::FETCH_ASSOC)) {
                    $this->pagos[] = $reg;
                }
                return $this->pagos;
            }
        }
    }
    // Función para insertar productos en factura y descargar archivo de la factura
    public function insertarProductosFactura($idpago, $nombreusuario) {
        $consulta = "select * from carritotienda WHERE nombreusuario = ?";
        $resultados = $this->db->prepare($consulta);
        $resultados->bindParam(1, $nombreusuario);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                foreach ($resultados as $res) {
                    $consulta = "INSERT INTO facturas(idpago, subtipoproducto, nombreproducto, cantidadproducto, 
                     precioproducto) VALUES (?, ?, ?, ?, ?)";
                    $idpago = htmlentities(addslashes($idpago));
                    $subtipoproducto = htmlentities(addslashes($res['subtipoproducto']));
                    $nombreproducto = htmlentities(addslashes($res['nombreproducto']));
                    $cantidadproducto = htmlentities(addslashes($res['cantidadproducto']));
                    $precioproducto = htmlentities(addslashes($res['precioproducto']));
                    $resultado = $this->db->prepare($consulta);
                    $resultado->bindParam(1, $idpago);
                    $resultado->bindParam(2, $subtipoproducto);
                    $resultado->bindParam(3, $nombreproducto);
                    $resultado->bindParam(4, $cantidadproducto);
                    $resultado->bindParam(5, $precioproducto);
                    $resultado->execute();
                }
                // Escribimos el archivo con los datos de tablas unidas
                $archivo = fopen("Factura.txt", "w");
                $consulta = "select * from facturas as f LEFT JOIN pagos as p ON f.idpago=p.idpago";
                $resultados = $this->db->prepare($consulta);
                if ($resultados->execute()) {
                    if ($resultados->rowCount() > 0) {
                        $resultados2 = $this->db->prepare("select * from infogeneral");
                        if ($resultados2->execute()) {
                            foreach ($resultados2 as $res2) {
                                foreach ($resultados as $res) {
                                    if ($i == 0) {
                                        fwrite($archivo, PHP_EOL . 'Productos Tecnológicos' . PHP_EOL
                                            . PHP_EOL . 'Dirección De La Tienda: ' . $res2['direccion'] . PHP_EOL .
                                            'Email: ' . $res2['email'] . PHP_EOL .
                                            'Teléfono De Contacto: ' . $res2['telefonocontacto'] . PHP_EOL . PHP_EOL .
                                            'Nombre y Apellidos: ' . $res['nombreyapellidos'] . PHP_EOL .
                                            'Dirección: ' . $res['direccion'] . ' (' . $res['poblacion'] . ', ' .
                                            $res['provincia'] . ') | Código Postal: ' . $res['codigopostal'] . PHP_EOL .
                                            'Número De Tarjeta: ' . $res['numerotarjeta'] .
                                            ' | Caducidad: ' . $res['mes'] . '/' . $res['ano']);
                                        if ($res['telefono'] > 0) {
                                            fwrite($archivo, ' | Teléfono: ' . $res['telefono']);
                                        }
                                        fwrite($archivo, PHP_EOL);
                                        $i = 1;
                                    }
                                    fwrite($archivo, PHP_EOL . $res['subtipoproducto'] . ' ' .
                                        $res['nombreproducto'] . ' -> ' . $res['cantidadproducto'] . ' X ' .
                                        $res['precioproducto'] . ' € = ' .
                                        $res['cantidadproducto'] * $res['precioproducto'] . ' €' . PHP_EOL);
                                }
                            }
                            fwrite($archivo, PHP_EOL . 'Total: ' . $res['totalgasto'] . ' €' . PHP_EOL);
                        }
                    }
                }
                fclose($archivo);
                // Descargar el archivo de factura
                $nombrearchivo = basename('Factura.txt');
                $filePath = $nombrearchivo;
                if(!empty($nombrearchivo) && file_exists($filePath)){
                    header('Content-Description: File Transfer');
                    header('Content-Type: application/octet-stream');
                    header('Content-Disposition: attachment; filename="'.basename('Factura.txt').'"');
                    header('Expires: 0');
                    header('Cache-Control: must-revalidate');
                    header('Pragma: public');
                    header('Content-Length: ' . filesize($nombrearchivo));
                    while (ob_get_level()) {
                        ob_end_clean();
                    }
                    readfile($filePath);
                }
                $consulta = "delete from facturas Where idpago = ?";
                $idpago = htmlentities(addslashes($idpago));
                $resultado = $this->db->prepare($consulta);
                $resultado->bindParam(1, $idpago);
                return $resultado->execute();
            }
        }
        return true;
    }
    public function insertarTotalPago() { // Función para insertar el total en la tarjeta al comprar
        $consulta = "UPDATE pagos SET totalgasto=:totalgasto 
                    WHERE nombreusuario=:nombreusuario AND numerotarjeta=:numerotarjeta";
        $nombreusuario = htmlentities(addslashes($_POST["usuariotarjeta"]));
        $numerotarjeta = htmlentities(addslashes($_POST["numerotarjeta"]));
        $totalgasto = htmlentities(addslashes($_POST["totalgastocesta"]));
        $res = $this->db->prepare($consulta);
        $res->bindParam(":nombreusuario", $nombreusuario);
        $res->bindParam(":numerotarjeta", $numerotarjeta);
        $res->bindParam(":totalgasto", $totalgasto);
        return $res->execute();
    }
    public function compraProductos() { // Función para actualizar productos al comprar
        $consulta = "UPDATE productostienda SET cantidad=cantidad-:cantidades 
                    WHERE idproducto=:idproducto";
        $idproducto = htmlentities(addslashes($_POST["idproductocesta"]));
        $cantidad = htmlentities(addslashes($_POST["cantidadproductocesta"]));
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(":idproducto", $idproducto);
        $resultado->bindParam(":cantidades", $cantidad);
        return $resultado->execute();
    }
    public function vaciaCesta($nombreusuario) { // Función para vaciar cesta del usuario
        $consulta = "delete from carritotienda Where nombreusuario=:nombreusuario";
        $nombreusuario = htmlentities(addslashes($nombreusuario));
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(":nombreusuario", $nombreusuario);
        return $resultado->execute();
    }
}
?>