<?php
class ComentariosModelo { // Creo las variables globales y privadas
    private $db;
    private $productos;
    public function __construct() { // Creo el constructor e incluyo la direccion de la Conexion
        require_once "Conexion.php";
        $this->db = Conexion::conectar();
        $this->productos = array();
        $this->comentariot = array();
        $this->comentariop = array();
    }
    public function totalComentariosTienda() { // Función para todos los comentarios de la tienda
        $consulta = "select * from comentariostienda order by valoracion desc, fecha desc";
        $resultado = $this->db->prepare($consulta);
        if ($resultado->execute()) {
            if ($resultado->rowCount() > 0) {
                while ($reg = $resultado->fetch(PDO::FETCH_ASSOC)) {
                    $this->comentariot[] = $reg;
                }
                return $this->comentariot;
            }
        }
    }
    public function totalComentariosProductos() { // Función para todos los comentarios del producto
        $consulta = "select * from comentariosproductos where nombreproducto=:nombreproducto 
        order by valoracion desc, fecha desc";
        $nombreproducto = htmlentities(addslashes($_GET["nombre"]));
        $resultado = $this->db->prepare($consulta);
        $resultado->bindParam(":nombreproducto", $_GET["nombre"]);
        if ($resultado->execute()) {
            if ($resultado->rowCount() > 0) {
                while ($reg = $resultado->fetch(PDO::FETCH_ASSOC)) {
                    $this->comentariop[] = $reg;
                }
                return $this->comentariop;
            }
        }
    }
    public function getTotalComentarios() { // Función para ver total de comentarios
        $consulta = "select count(*) as 'totalcomentarios' from comentariostienda";
        $resultados = $this->db->prepare($consulta);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                $reg = $resultados->fetch(PDO::FETCH_ASSOC);
                return $reg;
            }
        }
    }
    // Función para ver lista de comentarios
    public function getComentarioTienda($totalComentarios, $comentPorPag, $numpagcoment, $pagina) {
        $start = ($pagina - 1) * $comentPorPag;
        $consulta = "select * from comentariostienda order by valoracion desc, fecha desc limit $start, $comentPorPag";
        $resultados = $this->db->prepare($consulta);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                while ($reg = $resultados->fetch(PDO::FETCH_ASSOC)) {
                    $this->comentariot[] = $reg;
                }
                return $this->comentariot;
            }
        }
    }
    public function getTotalComentariosProductos() { // Función para ver total de comentarios del producto
        $consulta = "select count(*) as 'totalcomentariosp' from comentariosproductos";
        $resultados = $this->db->prepare($consulta);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                $reg = $resultados->fetch(PDO::FETCH_ASSOC);
                return $reg;
            }
        }
    }
    // Función para ver comentarios del producto
    public function getComentarioTiendaProductos($nombreproducto, $totalComentariosp,
                                                 $comentPorPagp, $numpagcomentp, $pagina) {
        $start = ($pagina - 1) * $comentPorPagp;
        $consulta = "select * from comentariosproductos where nombreproducto=:nombreproducto 
        order by valoracion desc, fecha desc limit $start, $comentPorPagp";
        $nombreproducto = htmlentities(addslashes($nombreproducto));
        $resultados = $this->db->prepare($consulta);
        $resultados->bindParam(":nombreproducto", $nombreproducto);
        if ($resultados->execute()) {
            if ($resultados->rowCount() > 0) {
                while ($reg = $resultados->fetch(PDO::FETCH_ASSOC)) {
                    $this->comentariop[] = $reg;
                }
                return $this->comentariop;
            }
        }
    }
    public function insertarComentarioTienda() { // Función para insertar nuevo comentario de la tienda
        $consulta = "INSERT INTO comentariostienda(nombreusuario, imagenusuario, valoracion, comentario) 
                    VALUES (:nombreusuario, :imagenusuario, :valoracion, :comentario)";
        $nombreusuario = htmlentities(addslashes($_POST["usuariocomentariotienda"]));
        $imagenusuariocomentario = htmlentities(addslashes($_POST["imagenusuariocomentario"]));
        $valoraciontienda = htmlentities(addslashes($_POST["valoraciontienda"]));
        $comentariotienda = htmlentities(addslashes($_POST["comentariotienda"]));
        $res = $this->db->prepare($consulta);
        $res->bindParam(":nombreusuario", $nombreusuario);
        $res->bindParam(":imagenusuario", $imagenusuariocomentario);
        $res->bindParam(":valoracion", $valoraciontienda);
        $res->bindParam(":comentario", $comentariotienda);
        return $res->execute();
    }
    public function insertarComentarioProducto() { // Función para insertar nuevo comentario del producto
        $consulta = "INSERT INTO comentariosproductos(nombreusuario, imagenusuario, valoracion, comentario, 
        nombreproducto) VALUES (:nombreusuario, :imagenusuario, :valoracion, :comentario, :nombreproducto)";
        $nombreusuario = htmlentities(addslashes($_POST["usuariocomentarioprod"]));
        $imagenusuariocomentario = htmlentities(addslashes($_POST["imagenusuariocomentario"]));
        $valoracionprod = htmlentities(addslashes($_POST["valoracionprod"]));
        $comentarioprod = htmlentities(addslashes($_POST["comentarioprod"]));
        $nombreproducto = htmlentities(addslashes($_POST["nombreproducto"]));
        $res = $this->db->prepare($consulta);
        $res->bindParam(":nombreusuario", $nombreusuario);
        $res->bindParam(":imagenusuario", $imagenusuariocomentario);
        $res->bindParam(":valoracion", $valoracionprod);
        $res->bindParam(":comentario", $comentarioprod);
        $res->bindParam(":nombreproducto", $nombreproducto);
        return $res->execute();
    }
}
?>